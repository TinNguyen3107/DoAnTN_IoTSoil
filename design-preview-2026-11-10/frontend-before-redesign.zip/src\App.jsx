import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AuthPage from './components/AuthPage.jsx';
import Sidebar from './components/Sidebar.jsx';
import Topbar from './components/Topbar.jsx';
import DashboardOverview from './components/DashboardOverview.jsx';
import DeviceManagement from './components/DeviceManagement.jsx';
import RealtimeMonitoring from './components/RealtimeMonitoring.jsx';
import ThresholdConfig from './components/ThresholdConfig.jsx';
import AlertManagement from './components/AlertManagement.jsx';
import AnalyticsHistory from './components/AnalyticsHistory.jsx';
import FieldLogs from './components/FieldLogs.jsx';
import Recommendations from './components/Recommendations.jsx';
import UserManagement from './components/UserManagement.jsx';
import SystemSettings from './components/SystemSettings.jsx';

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [authChecking, setAuthChecking] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [devices, setDevices] = useState([]);
  const [unreadAlerts, setUnreadAlerts] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Tải số lượng cảnh báo chưa xử lý
  const loadAlertsCount = async () => {
    try {
      const res = await axios.get('/api/alerts/unread-count');
      if (res.data?.success) {
        setUnreadAlerts(res.data.data.unreadCount || 0);
      }
    } catch (err) {
      // Bỏ qua lỗi
    }
  };

  // Kiểm tra phiên đăng nhập đã lưu trong LocalStorage khi mở web
  useEffect(() => {
    try {
      const savedToken = localStorage.getItem('agro_token');
      const savedUser = localStorage.getItem('agro_user');

      if (savedToken && savedUser) {
        const parsedUser = JSON.parse(savedUser);
        setCurrentUser(parsedUser);
        axios.defaults.headers.common['Authorization'] = `Bearer ${savedToken}`;
        // Nếu là Nông dân, mặc định đưa vào tab Giám sát thực địa
        setActiveTab(parsedUser.role === 'admin' ? 'dashboard' : 'telemetry');
      }
    } catch (err) {
      console.error('Lỗi khôi phục phiên đăng nhập:', err);
      localStorage.removeItem('agro_token');
      localStorage.removeItem('agro_user');
    } finally {
      setAuthChecking(false);
    }
  }, []);

  // Tải danh sách thiết bị
  const loadDevices = async () => {
    if (!currentUser) return;
    try {
      setIsRefreshing(true);
      // Nông dân chỉ lấy trạm thuộc sở hữu của mình, Admin lấy toàn bộ
      const url = currentUser.role === 'admin' 
        ? '/api/devices' 
        : `/api/devices?ownerId=${currentUser.id}`;
      const res = await axios.get(url);
      if (res.data?.success) {
        setDevices(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi nạp danh sách thiết bị:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    if (currentUser) {
      loadDevices();
      loadAlertsCount();
    }
  }, [currentUser]);

  // Xử lý Đăng xuất
  const handleLogout = () => {
    localStorage.removeItem('agro_token');
    localStorage.removeItem('agro_user');
    delete axios.defaults.headers.common['Authorization'];
    setCurrentUser(null);
  };

  // Map breadcrumbs theo tab đang chọn
  const getBreadcrumbs = () => {
    switch (activeTab) {
      case 'dashboard':
        return ['Tổng quan hệ thống'];
      case 'telemetry':
        return ['Giám sát', 'Chất lượng đất thời gian thực'];
      case 'devices':
        return ['Thiết bị', currentUser?.role === 'admin' ? 'Trạm quan trắc & Khóa' : 'Trạm đo của tôi'];
      case 'thresholds':
        return ['Cấu hình', 'Ngưỡng cảnh báo đất'];
      case 'alerts':
        return ['Cảnh báo', 'Cảnh báo vượt ngưỡng'];
      case 'analytics':
        return ['Báo cáo', 'Biểu đồ lịch sử & Xuất CSV'];
      case 'field_logs':
        return ['Nhật ký', 'Sổ nhật ký đồng ruộng'];
      case 'recommendations':
        return ['Tư vấn', 'Liều lượng NPK & Cây trồng'];
      case 'users':
        return ['Quản trị', 'Người dùng & Phân quyền'];
      case 'settings':
        return ['Hệ thống', 'Cài đặt tham số'];
      default:
        return ['Hệ thống'];
    }
  };

  // Màn hình chờ khi đang đọc Token
  if (authChecking) {
    return (
      <div className="min-h-screen bg-[#F7F9F7] flex items-center justify-center text-xs text-[#718078] font-mono">
        Đang khởi tạo phiên làm việc...
      </div>
    );
  }

  // 1. NẾU CHƯA ĐĂNG NHẬP: Hiển thị Màn hình Đăng Nhập / Đăng Ký (UC-01 & UC-02)
  if (!currentUser) {
    return (
      <AuthPage 
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setActiveTab(user.role === 'admin' ? 'dashboard' : 'telemetry');
        }} 
      />
    );
  }

  // 2. NẾU ĐÃ ĐĂNG NHẬP: Hiển thị Giao diện theo đúng vai trò (Nông dân vs Admin)
  return (
    <div className="min-h-screen bg-[#F7F9F7] text-[#202B24] flex antialiased">
      {/* Sidebar phân quyền */}
      <Sidebar 
        activeTab={activeTab} 
        onSelectTab={setActiveTab} 
        counts={{ devices: devices.length, alerts: unreadAlerts }}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Vùng làm việc chính */}
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar 
          breadcrumbs={getBreadcrumbs()}
          onRefresh={() => { loadDevices(); loadAlertsCount(); }}
          isRefreshing={isRefreshing}
          currentUser={currentUser}
          onLogout={handleLogout}
          onOpenAlerts={() => setActiveTab('alerts')}
        />

        <main className="flex-1 p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && currentUser.role === 'admin' && (
            <DashboardOverview 
              devices={devices} 
              unreadAlerts={unreadAlerts}
              onNavigateToDevices={() => setActiveTab('devices')} 
              onNavigateToAlerts={() => setActiveTab('alerts')}
            />
          )}

          {activeTab === 'telemetry' && (
            <RealtimeMonitoring 
              devices={devices} 
              onNavigateToDevices={() => setActiveTab('devices')} 
            />
          )}

          {activeTab === 'devices' && (
            <DeviceManagement 
              currentUser={currentUser} 
              onDevicesChanged={loadDevices} 
            />
          )}

          {activeTab === 'thresholds' && currentUser.role === 'admin' && (
            <ThresholdConfig />
          )}

          {activeTab === 'alerts' && (
            <AlertManagement onAlertResolved={loadAlertsCount} />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsHistory devices={devices} />
          )}

          {activeTab === 'field_logs' && (
            <FieldLogs devices={devices} />
          )}

          {activeTab === 'recommendations' && (
            <Recommendations devices={devices} />
          )}

          {activeTab === 'users' && currentUser.role === 'admin' && (
            <UserManagement currentUser={currentUser} />
          )}

          {activeTab === 'settings' && currentUser.role === 'admin' && (
            <SystemSettings />
          )}
        </main>
      </div>
    </div>
  );
}
