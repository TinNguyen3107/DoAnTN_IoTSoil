import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Bell, 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle2, 
  Check, 
  RefreshCw, 
  Filter, 
  Radio, 
  Smartphone,
  Clock,
  CheckCheck,
  ShieldCheck,
  Info
} from 'lucide-react';

export default function AlertManagement({ onAlertResolved }) {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterMode, setFilterMode] = useState('unresolved'); // 'unresolved' | 'all' | 'resolved'
  const [resolvingId, setResolvingId] = useState(null);
  const [actionNotes, setActionNotes] = useState({});

  // UC-12 Step 2 & 3: Tải danh sách cảnh báo từ máy chủ
  const fetchAlerts = async () => {
    try {
      setLoading(true);
      const unreadParam = filterMode === 'unresolved' ? '?unreadOnly=true' : '';
      const res = await axios.get(`/api/alerts${unreadParam}`);
      if (res.data?.success) {
        setAlerts(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi tải danh sách cảnh báo:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, [filterMode]);

  // UC-13 Step 1, 2, 3: Đánh dấu 1 cảnh báo đã xử lý
  const handleResolveOne = async (alertId) => {
    const note = actionNotes[alertId] || 'Đã kiểm tra thực địa và xử lý nông học';
    try {
      setResolvingId(alertId);
      const res = await axios.patch(`/api/alerts/${alertId}/resolve`, {
        actionTaken: note
      });
      if (res.data?.success) {
        fetchAlerts();
        onAlertResolved?.();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi khi xử lý cảnh báo.');
    } finally {
      setResolvingId(null);
    }
  };

  // UC-13 Step 1a, 2, 3: Đánh dấu tất cả cảnh báo đã xử lý
  const handleResolveAll = async () => {
    if (!window.confirm('Xác nhận đánh dấu TẤT CẢ các cảnh báo hiện tại là đã xử lý?')) {
      return;
    }
    try {
      setLoading(true);
      const res = await axios.patch('/api/alerts/resolve-all');
      if (res.data?.success) {
        fetchAlerts();
        onAlertResolved?.();
      }
    } catch (err) {
      alert('Lỗi khi xử lý toàn bộ cảnh báo.');
    } finally {
      setLoading(false);
    }
  };

  const unresolvedCount = alerts.filter(a => !a.isResolved).length;

  return (
    <div className="space-y-6">
      {/* Page Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
              Quản Lý Cảnh Báo Vượt Ngưỡng
            </h1>
            {unresolvedCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#FCECEC] text-[#DC6262] border border-[#F8D2D2]">
                {unresolvedCount} cần xử lý
              </span>
            )}
          </div>
          <p className="text-xs text-[#718078] mt-1">
            Theo dõi danh sách các chỉ số đất bị vi phạm dải an toàn và ghi nhận biện pháp khắc phục thực địa.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {unresolvedCount > 0 && (
            <button
              onClick={handleResolveAll}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#CDE5D4] bg-[#EAF4EC] hover:bg-[#DDF0E1] text-xs font-semibold text-[#27864B] transition-colors shadow-xs"
              title="Đánh dấu tất cả cảnh báo là đã đọc (UC-13 Step 1a)"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Xác Nhận Toàn Bộ</span>
            </button>
          )}

          <button
            onClick={fetchAlerts}
            className="p-2 rounded-lg border border-[#E5EBE6] bg-white hover:bg-[#F2F5F3] text-[#718078] transition-colors"
            title="Làm mới"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#27864B]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-2.5 shadow-subtle flex items-center justify-between">
        <div className="inline-flex p-0.5 rounded-lg bg-[#F7F9F7] border border-[#E5EBE6] text-xs">
          <button
            onClick={() => setFilterMode('unresolved')}
            className={`px-3 py-1.5 rounded-md font-medium transition-all ${
              filterMode === 'unresolved'
                ? 'bg-white text-[#DC6262] font-semibold shadow-xs'
                : 'text-[#718078] hover:text-[#202B24]'
            }`}
          >
            Chưa xử lý ({unresolvedCount})
          </button>
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-md font-medium transition-all ${
              filterMode === 'all'
                ? 'bg-white text-[#202B24] font-semibold shadow-xs'
                : 'text-[#718078] hover:text-[#202B24]'
            }`}
          >
            Tất cả cảnh báo ({alerts.length})
          </button>
        </div>

        <div className="text-[11px] text-[#718078] hidden sm:flex items-center gap-1.5 font-mono">
          <span className="w-2 h-2 rounded-full bg-[#26965A]"></span>
          <span>Tự động quét khi có số đo mới</span>
        </div>
      </div>

      {/* Alert List Container */}
      <div className="space-y-3">
        {loading ? (
          <div className="bg-white border border-[#E5EBE6] rounded-card p-16 text-center text-xs text-[#718078] shadow-subtle">
            <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
            Đang tải dữ liệu cảnh báo từ máy chủ...
          </div>
        ) : alerts.length === 0 ? (
          // UC-12 Step 3a: Không còn cảnh báo chưa đọc
          <div className="bg-white border border-[#E5EBE6] rounded-card p-12 text-center shadow-subtle space-y-2">
            <div className="w-12 h-12 rounded-full bg-[#EAF4EC] text-[#27864B] flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div className="text-sm font-bold text-[#202B24]">
              {filterMode === 'unresolved' ? 'Không còn cảnh báo nào chưa xử lý' : 'Chưa có bản ghi cảnh báo nào'}
            </div>
            <p className="text-xs text-[#718078] max-w-sm mx-auto">
              Chỉ số thổ nhưỡng trên các trạm đo hiện đều nằm trong dải an toàn tham chiếu hoặc toàn bộ cảnh báo đã được xác nhận.
            </p>
          </div>
        ) : (
          alerts.map((alert) => {
            const isDanger = alert.level === 'danger';
            const isResolved = alert.isResolved;

            return (
              <div
                key={alert.id}
                className={`border rounded-card p-4 transition-all shadow-subtle ${
                  isResolved
                    ? 'bg-[#FCFDFD] border-[#E5EBE6] opacity-75'
                    : isDanger
                    ? 'bg-[#FFF8F8] border-[#F8D2D2]'
                    : 'bg-[#FFFCF5] border-[#FEE685]'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  {/* Left Column: Severity & Details */}
                  <div className="flex items-start gap-3 min-w-0">
                    <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                      isResolved
                        ? 'bg-[#F2F5F3] text-[#718078]'
                        : isDanger
                        ? 'bg-[#FCECEC] text-[#DC6262]'
                        : 'bg-[#FDF6E9] text-[#D97706]'
                    }`}>
                      {isResolved ? (
                        <Check className="w-5 h-5" />
                      ) : isDanger ? (
                        <AlertTriangle className="w-5 h-5" />
                      ) : (
                        <AlertCircle className="w-5 h-5" />
                      )}
                    </div>

                    <div className="space-y-1.5 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                          isResolved
                            ? 'bg-[#F2F5F3] text-[#718078]'
                            : isDanger
                            ? 'bg-[#FCECEC] text-[#DC6262] border border-[#F8D2D2]'
                            : 'bg-[#FDF6E9] text-[#D97706] border border-[#FEE685]'
                        }`}>
                          {isResolved ? 'ĐÃ XỬ LÝ' : isDanger ? 'NGUY HIỂM (DANGER)' : 'CẢNH BÁO (WARNING)'}
                        </span>

                        <span className="font-bold text-sm text-[#202B24]">
                          {alert.parameterName}
                        </span>

                        <span className="text-xs font-mono font-bold text-[#202B24]">
                          = {alert.value} {alert.unit}
                        </span>

                        <span className="text-xs text-[#718078]">
                          (Ngưỡng: {alert.limitValue} {alert.unit})
                        </span>
                      </div>

                      {/* Diagnostic Guidance Message */}
                      <p className="text-xs text-[#202B24] leading-relaxed">
                        {alert.diagnosticMessage}
                      </p>

                      {/* Device & Timestamp Info */}
                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-[#718078] pt-1">
                        <span className="font-semibold text-[#202B24] flex items-center gap-1">
                          {alert.deviceType === 'fixed' ? <Radio className="w-3 h-3 text-[#2563EB]" /> : <Smartphone className="w-3 h-3 text-[#D97706]" />}
                          <span>{alert.deviceName}</span>
                        </span>
                        <span>•</span>
                        <span className="font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(alert.createdAt).toLocaleString('vi-VN')}</span>
                        </span>
                        {isResolved && alert.actionTaken && (
                          <>
                            <span>•</span>
                            <span className="text-[#27864B] font-medium">
                              Biện pháp: {alert.actionTaken}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right Column: UC-13 Action Button */}
                  <div className="shrink-0 flex flex-col sm:flex-row items-end sm:items-center gap-2">
                    {!isResolved ? (
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <input
                          type="text"
                          placeholder="Ghi chú biện pháp xử lý..."
                          value={actionNotes[alert.id] || ''}
                          onChange={(e) => setActionNotes({ ...actionNotes, [alert.id]: e.target.value })}
                          className="bg-white border border-[#E5EBE6] rounded-lg px-2.5 py-1.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] w-48 hidden lg:block"
                        />
                        <button
                          onClick={() => handleResolveOne(alert.id)}
                          disabled={resolvingId === alert.id}
                          className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors shadow-xs"
                          title="Đánh dấu đã đọc / đã xử lý (UC-13 Step 1)"
                        >
                          {resolvingId === alert.id ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Check className="w-3.5 h-3.5" />
                          )}
                          <span>Đã Xử Lý</span>
                        </button>
                      </div>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#718078] bg-[#F2F5F3] px-2.5 py-1 rounded-md">
                        <Check className="w-3 h-3 text-[#26965A]" />
                        <span>Hoàn tất xử lý</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
