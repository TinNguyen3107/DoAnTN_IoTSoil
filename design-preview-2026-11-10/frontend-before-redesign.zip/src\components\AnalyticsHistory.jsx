import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  LineChart as ChartIcon, 
  Download, 
  Calendar, 
  Filter, 
  ArrowDownToLine,
  CheckCircle2,
  RefreshCw,
  Radio,
  Smartphone,
  Sprout,
  AlertCircle,
  Clock,
  Layers,
  ChevronDown,
  Info
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ReferenceLine 
} from 'recharts';

export default function AnalyticsHistory({ devices = [] }) {
  // Trạng thái trạm đo được chọn
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  
  // Trạng thái khoảng thời gian lọc (24h, 7d, 30d, custom)
  const [datePreset, setDatePreset] = useState('7d');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  // Trạng thái dữ liệu lịch sử
  const [loading, setLoading] = useState(false);
  const [historyData, setHistoryData] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Bật/tắt từng đường chỉ số (Quy tắc nghiệp vụ US-10: Checkbox toggle)
  const [visibleSeries, setVisibleSeries] = useState({
    n: true,
    p: true,
    k: true,
    ph: false,
    ec: false,
    temperature: false,
    moisture: false
  });

  // Tự động khởi tạo khoảng thời gian theo preset
  const applyPreset = (preset) => {
    setDatePreset(preset);
    const now = new Date();
    const to = now.toISOString().slice(0, 10);
    let from = '';

    if (preset === '24h') {
      const past = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      from = past.toISOString().slice(0, 10);
    } else if (preset === '7d') {
      const past = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      from = past.toISOString().slice(0, 10);
    } else if (preset === '30d') {
      const past = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      from = past.toISOString().slice(0, 10);
    }

    setFromDate(from);
    setToDate(to);
  };

  // Khởi tạo / đồng bộ trạm đo mặc định khi danh sách trạm thay đổi
  useEffect(() => {
    if (devices.length > 0) {
      const exists = devices.some(d => String(d.id) === String(selectedDeviceId));
      if (!selectedDeviceId || !exists) {
        setSelectedDeviceId(String(devices[0].id));
      }
    } else {
      setSelectedDeviceId('');
      setHistoryData(null);
    }
  }, [devices]);

  useEffect(() => {
    applyPreset('7d');
  }, []);

  // Tải dữ liệu lịch sử biến thiên (UC-10 Step 2, 3, 4, 5)
  const fetchHistory = async () => {
    if (!selectedDeviceId) return;

    try {
      setLoading(true);
      setErrorMessage('');

      let url = `/api/readings/history?deviceId=${selectedDeviceId}`;
      if (fromDate) url += `&fromDate=${fromDate}`;
      if (toDate) url += `&toDate=${toDate}`;

      const res = await axios.get(url);
      if (res.data?.success) {
        setHistoryData(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi nạp dữ liệu lịch sử:', err);
      setErrorMessage(err.response?.data?.message || 'Không thể tải dữ liệu lịch sử biến thiên.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedDeviceId && fromDate && toDate) {
      fetchHistory();
    }
  }, [selectedDeviceId, datePreset]);

  // Xử lý Xuất báo cáo CSV UTF-8 BOM (UC-11)
  const handleExportCsv = async () => {
    if (!selectedDeviceId) return;
    if (!historyData || historyData.totalReadings === 0) return;

    try {
      setExporting(true);
      let url = `/api/readings/export-csv?deviceId=${selectedDeviceId}`;
      if (fromDate) url += `&fromDate=${fromDate}`;
      if (toDate) url += `&toDate=${toDate}`;

      const res = await axios.get(url, { responseType: 'blob' });

      // Lấy tên tệp từ header Content-Disposition hoặc đặt tên mặc định
      const disposition = res.headers['content-disposition'];
      let filename = `BaoCao_SoDo_${selectedDeviceId}_${fromDate}_${toDate}.csv`;
      if (disposition && disposition.includes('filename=')) {
        const matches = disposition.match(/filename="?([^"]+)"?/);
        if (matches && matches[1]) filename = matches[1];
      }

      // Kích hoạt trình duyệt tải tệp về máy
      const blob = new Blob([res.data], { type: 'text/csv;charset=utf-8;' });
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      alert(err.response?.data?.message || 'Có lỗi xảy ra khi xuất báo cáo CSV.');
    } finally {
      setExporting(false);
    }
  };

  const toggleSeries = (key) => {
    setVisibleSeries(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const selectedDevice = devices.find(d => String(d.id) === String(selectedDeviceId));
  const readings = historyData?.readings || [];
  const events = historyData?.events || [];
  const summary = historyData?.summary;
  const hasReadings = readings.length > 0;

  // Cấu hình danh mục 7 thông số cảm biến
  const parameterConfigs = [
    { key: 'n', label: 'Đạm (N)', unit: 'mg/kg', color: '#27864B', yAxis: 'left' },
    { key: 'p', label: 'Lân (P)', unit: 'mg/kg', color: '#2563EB', yAxis: 'left' },
    { key: 'k', label: 'Kali (K)', unit: 'mg/kg', color: '#7C3AED', yAxis: 'left' },
    { key: 'ec', label: 'EC', unit: 'µS/cm', color: '#DC2626', yAxis: 'left' },
    { key: 'ph', label: 'Độ chua (pH)', unit: '', color: '#D97706', yAxis: 'right' },
    { key: 'temperature', label: 'Nhiệt độ', unit: '°C', color: '#EA580C', yAxis: 'right' },
    { key: 'moisture', label: 'Độ ẩm', unit: '%', color: '#0D9488', yAxis: 'right' },
  ];

  // Tooltip tùy biến chi tiết (Quy tắc US-10: Hover hiện 7 thông số và sự kiện bón phân)
  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;

    const currentPoint = payload[0]?.payload;
    const matchingEvent = events.find(e => e.eventDate === currentPoint?.dateOnly || currentPoint?.timeLabel?.includes(e.eventDate));

    return (
      <div className="bg-white border border-[#E5EBE6] rounded-xl p-3.5 shadow-modal text-xs space-y-2 min-w-[220px]">
        <div className="flex items-center justify-between border-b border-[#E5EBE6] pb-1.5 font-mono text-[11px] text-[#718078]">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-[#9CAAA2]" />
            <span>{currentPoint?.timeLabel || label}</span>
          </span>
          <span className="px-1.5 py-0.2 rounded bg-[#F2F5F3] text-[#202B24] font-medium">
            {currentPoint?.mode === 'auto' ? 'Tự động' : 'Cầm tay'}
          </span>
        </div>

        {/* Các thông số đang bật */}
        <div className="space-y-1">
          {payload.map((item) => {
            const cfg = parameterConfigs.find(c => c.key === item.dataKey);
            return (
              <div key={item.dataKey} className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-[#718078]">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                  <span>{item.name}:</span>
                </span>
                <span className="font-mono font-bold text-[#202B24]">
                  {item.value} {cfg?.unit}
                </span>
              </div>
            );
          })}
        </div>

        {/* Gắn cọc mốc sự kiện canh tác nếu có */}
        {matchingEvent && (
          <div className="pt-2 border-t border-[#E5EBE6] space-y-1">
            <div className="flex items-center gap-1.5 text-[#27864B] font-bold text-[11px]">
              <Sprout className="w-3.5 h-3.5" />
              <span>{matchingEvent.eventType} ({matchingEvent.amount} {matchingEvent.unit})</span>
            </div>
            {matchingEvent.notes && (
              <p className="text-[10px] text-[#718078] leading-tight">
                {matchingEvent.notes}
              </p>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Tiêu đề trang & Nút xuất báo cáo */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Lịch Sử Biến Thiên & Báo Cáo Thổ Nhưỡng
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Phân tích xu hướng diễn biến NPK, pH, EC theo chuỗi thời gian và trích xuất dữ liệu đo lường định dạng CSV chuẩn hóa.
          </p>
        </div>

        {/* UC-11: Nút xuất báo cáo CSV */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCsv}
            disabled={!hasReadings || exporting}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border text-xs font-semibold transition-all shadow-xs ${
              !hasReadings || exporting
                ? 'bg-[#F2F5F3] text-[#9CAAA2] border-[#E5EBE6] cursor-not-allowed'
                : 'bg-white hover:bg-[#F2F5F3] text-[#202B24] border-[#E5EBE6] hover:border-[#CDE5D4]'
            }`}
            title={!hasReadings ? 'Không có dữ liệu trong khoảng thời gian đã chọn để xuất' : 'Xuất dữ liệu định dạng CSV chuẩn Microsoft Excel'}
          >
            <ArrowDownToLine className={`w-3.5 h-3.5 ${exporting ? 'animate-bounce text-[#27864B]' : 'text-[#27864B]'}`} />
            <span>{exporting ? 'Đang kết xuất...' : 'Xuất Báo Cáo CSV (Excel)'}</span>
          </button>
        </div>
      </div>

      {/* Thanh công cụ lọc: Chọn trạm & Khoảng thời gian */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-3.5 shadow-subtle flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Chọn trạm quan trắc */}
        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-[#718078] shrink-0">Trạm quan trắc:</label>
          <div className="relative min-w-[240px]">
            <select
              value={selectedDeviceId}
              onChange={(e) => setSelectedDeviceId(e.target.value)}
              disabled={devices.length === 0}
              className="w-full appearance-none bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-1.5 pr-8 text-xs font-semibold text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors cursor-pointer disabled:opacity-60"
            >
              {devices.length === 0 ? (
                <option value="">Chưa có trạm đo nào</option>
              ) : (
                devices.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.type === 'fixed' ? 'Cố định' : 'Cầm tay'})
                  </option>
                ))
              )}
            </select>
            <ChevronDown className="w-4 h-4 text-[#9CAAA2] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* Khoảng thời gian */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex p-0.5 rounded-lg bg-[#F7F9F7] border border-[#E5EBE6] text-xs">
            {[
              { id: '24h', label: '24 giờ' },
              { id: '7d', label: '7 ngày' },
              { id: '30d', label: '30 ngày' },
              { id: 'custom', label: 'Tùy chọn' },
            ].map((preset) => (
              <button
                key={preset.id}
                onClick={() => applyPreset(preset.id)}
                className={`px-3 py-1 rounded-md font-medium transition-all ${
                  datePreset === preset.id
                    ? 'bg-white text-[#202B24] shadow-xs font-semibold'
                    : 'text-[#718078] hover:text-[#202B24]'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>

          {/* Ô nhập ngày tùy chọn */}
          {datePreset === 'custom' && (
            <div className="flex items-center gap-2 text-xs">
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-2.5 py-1 text-xs text-[#202B24] focus:outline-none focus:border-[#27864B]"
              />
              <span className="text-[#9CAAA2]">→</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-2.5 py-1 text-xs text-[#202B24] focus:outline-none focus:border-[#27864B]"
              />
              <button
                onClick={fetchHistory}
                className="px-3 py-1 bg-[#27864B] hover:bg-[#1F713E] text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Lọc
              </button>
            </div>
          )}

          <button
            onClick={fetchHistory}
            className="p-1.5 rounded-lg border border-[#E5EBE6] hover:bg-[#F2F5F3] text-[#718078] transition-colors"
            title="Làm mới dữ liệu biểu đồ"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#27864B]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Thông báo chế độ lấy mẫu đại diện (Alt 3b) */}
      {historyData?.isDownsampled && (
        <div className="p-3 bg-[#F2F7F4] border border-[#CDE5D4] rounded-xl flex items-center gap-2.5 text-xs text-[#27864B]">
          <Info className="w-4 h-4 shrink-0 text-[#27864B]" />
          <span>
            Khoảng thời gian chứa <strong>{historyData.totalReadings}</strong> số đo. Hệ thống đã tự động gộp mẫu trung bình để tối ưu tốc độ kết xuất biểu đồ; khi xuất tệp CSV vẫn bảo toàn 100% dữ liệu gốc.
          </span>
        </div>
      )}

      {/* Thanh Checkbox Bật/Tắt từng thông số (Quy tắc US-10) */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-3 shadow-subtle flex flex-wrap items-center gap-2 sm:gap-3">
        <span className="text-xs font-semibold text-[#718078] mr-1 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5" />
          <span>Chỉ số hiển thị:</span>
        </span>

        {parameterConfigs.map((cfg) => {
          const isChecked = visibleSeries[cfg.key];
          return (
            <button
              key={cfg.key}
              onClick={() => toggleSeries(cfg.key)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-medium transition-all ${
                isChecked
                  ? 'bg-white shadow-xs font-semibold'
                  : 'bg-[#F7F9F7] text-[#9CAAA2] border-transparent opacity-60 hover:opacity-100'
              }`}
              style={{
                borderColor: isChecked ? cfg.color : '#E5EBE6',
                color: isChecked ? '#202B24' : '#718078'
              }}
            >
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: isChecked ? cfg.color : '#D1DCD5' }}
              ></span>
              <span>{cfg.label}</span>
            </button>
          );
        })}
      </div>

      {/* Vùng Vẽ Biểu Đồ Chính */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#E5EBE6] pb-3 gap-2">
          <div>
            <h2 className="text-sm font-bold text-[#202B24]">
              Biến Động Nồng Độ Dinh Dưỡng Thổ Nhưỡng
            </h2>
            <p className="text-[11px] text-[#718078] mt-0.5">
              Đường biểu diễn chuỗi số đo theo thời gian; các cột mốc dọc thể hiện đợt bón phân canh tác thực địa.
            </p>
          </div>

          {events.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-[#27864B] font-medium bg-[#EAF4EC] px-2.5 py-1 rounded-full border border-[#CDE5D4]">
              <Sprout className="w-3.5 h-3.5" />
              <span>{events.length} đợt bón phân được đồng bộ</span>
            </div>
          )}
        </div>

        {/* Khung Biểu Đồ Recharts */}
        <div className="h-80 w-full pt-2">
          {loading ? (
            <div className="h-full flex items-center justify-center text-xs text-[#718078]">
              <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
              <span className="ml-2">Đang nạp dữ liệu chuỗi số đo...</span>
            </div>
          ) : !hasReadings ? (
            // UC-10 Alt 3a: Khoảng thời gian chọn không có bản ghi nào
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
              <div className="w-10 h-10 rounded-full bg-[#F2F5F3] text-[#718078] flex items-center justify-center">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div className="text-sm font-bold text-[#202B24]">
                Không có dữ liệu số đo trong khoảng thời gian đã chọn
              </div>
              <p className="text-xs text-[#718078] max-w-sm">
                Vui lòng chọn khoảng ngày khác hoặc khởi động thiết bị gửi số đo lên hệ thống để theo dõi biểu đồ.
              </p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={readings} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F0F4F1" vertical={false} />
                
                <XAxis 
                  dataKey="timeLabel" 
                  stroke="#9CAAA2" 
                  fontSize={10} 
                  tickLine={false} 
                />
                
                {/* Trục Y bên trái: N, P, K, EC */}
                <YAxis 
                  yAxisId="left" 
                  stroke="#9CAAA2" 
                  fontSize={10} 
                  tickLine={false}
                  domain={[0, 'auto']}
                />

                {/* Trục Y bên phải: pH, Nhiệt độ, Độ ẩm */}
                <YAxis 
                  yAxisId="right" 
                  orientation="right" 
                  stroke="#9CAAA2" 
                  fontSize={10} 
                  tickLine={false}
                  domain={[0, 100]}
                />

                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />

                {/* Các đường chỉ số được cấu hình bật/tắt */}
                {visibleSeries.n && (
                  <Line 
                    yAxisId="left" 
                    type="monotone" 
                    dataKey="n" 
                    name="Đạm (N)" 
                    stroke="#27864B" 
                    strokeWidth={2.2} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }} 
                  />
                )}
                {visibleSeries.p && (
                  <Line 
                    yAxisId="left" 
                    type="monotone" 
                    dataKey="p" 
                    name="Lân (P)" 
                    stroke="#2563EB" 
                    strokeWidth={2.2} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }} 
                  />
                )}
                {visibleSeries.k && (
                  <Line 
                    yAxisId="left" 
                    type="monotone" 
                    dataKey="k" 
                    name="Kali (K)" 
                    stroke="#7C3AED" 
                    strokeWidth={2.2} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }} 
                  />
                )}
                {visibleSeries.ec && (
                  <Line 
                    yAxisId="left" 
                    type="monotone" 
                    dataKey="ec" 
                    name="Độ dẫn điện (EC)" 
                    stroke="#DC2626" 
                    strokeWidth={1.8} 
                    dot={{ r: 2.5 }} 
                  />
                )}
                {visibleSeries.ph && (
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="ph" 
                    name="Độ chua (pH)" 
                    stroke="#D97706" 
                    strokeWidth={2} 
                    dot={{ r: 3 }} 
                  />
                )}
                {visibleSeries.temperature && (
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="temperature" 
                    name="Nhiệt độ (°C)" 
                    stroke="#EA580C" 
                    strokeWidth={1.8} 
                    strokeDasharray="4 4" 
                    dot={false} 
                  />
                )}
                {visibleSeries.moisture && (
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="moisture" 
                    name="Độ ẩm (%)" 
                    stroke="#0D9488" 
                    strokeWidth={1.8} 
                    strokeDasharray="3 3" 
                    dot={false} 
                  />
                )}

                {/* Vẽ các cọc mốc dọc đánh dấu sự kiện bón phân (UC-10 Step 6) */}
                {events.map((evt) => {
                  const matchingReading = readings.find(r => r.dateOnly === evt.eventDate || r.timeLabel.includes(evt.eventDate));
                  if (!matchingReading) return null;

                  return (
                    <ReferenceLine
                      key={evt.id}
                      x={matchingReading.timeLabel}
                      yAxisId="left"
                      stroke="#27864B"
                      strokeDasharray="3 3"
                      strokeWidth={1.5}
                      label={{
                        value: `🌱 ${evt.eventType}`,
                        position: 'top',
                        fill: '#27864B',
                        fontSize: 10,
                        fontWeight: 'bold'
                      }}
                    />
                  );
                })}
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Các Thẻ Thống Kê Tổng Hợp KPI */}
      {hasReadings && summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
          <div className="bg-white border border-[#E5EBE6] rounded-card p-3.5 shadow-subtle">
            <div className="text-[11px] font-semibold text-[#718078]">Đạm (N) Trung Bình</div>
            <div className="text-lg font-bold font-mono text-[#27864B] mt-1">
              {summary.n?.avg} <span className="text-[11px] font-normal text-[#718078]">mg/kg</span>
            </div>
            <div className="text-[10px] text-[#718078] mt-1 font-mono">
              Min: {summary.n?.min} • Max: {summary.n?.max}
            </div>
          </div>

          <div className="bg-white border border-[#E5EBE6] rounded-card p-3.5 shadow-subtle">
            <div className="text-[11px] font-semibold text-[#718078]">Lân (P) Trung Bình</div>
            <div className="text-lg font-bold font-mono text-[#2563EB] mt-1">
              {summary.p?.avg} <span className="text-[11px] font-normal text-[#718078]">mg/kg</span>
            </div>
            <div className="text-[10px] text-[#718078] mt-1 font-mono">
              Min: {summary.p?.min} • Max: {summary.p?.max}
            </div>
          </div>

          <div className="bg-white border border-[#E5EBE6] rounded-card p-3.5 shadow-subtle">
            <div className="text-[11px] font-semibold text-[#718078]">Kali (K) Trung Bình</div>
            <div className="text-lg font-bold font-mono text-[#7C3AED] mt-1">
              {summary.k?.avg} <span className="text-[11px] font-normal text-[#718078]">mg/kg</span>
            </div>
            <div className="text-[10px] text-[#718078] mt-1 font-mono">
              Min: {summary.k?.min} • Max: {summary.k?.max}
            </div>
          </div>

          <div className="bg-white border border-[#E5EBE6] rounded-card p-3.5 shadow-subtle">
            <div className="text-[11px] font-semibold text-[#718078]">Độ Chua (pH) TB</div>
            <div className="text-lg font-bold font-mono text-[#D97706] mt-1">
              {summary.ph?.avg}
            </div>
            <div className="text-[10px] text-[#718078] mt-1 font-mono">
              Min: {summary.ph?.min} • Max: {summary.ph?.max}
            </div>
          </div>

          <div className="bg-white border border-[#E5EBE6] rounded-card p-3.5 shadow-subtle col-span-2 md:col-span-1">
            <div className="text-[11px] font-semibold text-[#718078]">Độ Dẫn Điện (EC) TB</div>
            <div className="text-lg font-bold font-mono text-[#DC2626] mt-1">
              {summary.ec?.avg} <span className="text-[11px] font-normal text-[#718078]">µS/cm</span>
            </div>
            <div className="text-[10px] text-[#718078] mt-1 font-mono">
              Min: {summary.ec?.min} • Max: {summary.ec?.max}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
