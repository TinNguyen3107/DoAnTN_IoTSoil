import React, { useState } from 'react';
import axios from 'axios';
import BrandLogo from './BrandLogo.jsx';
import { 
  Mail, 
  Lock, 
  User, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  ShieldCheck,
  Sprout
} from 'lucide-react';

export default function AuthPage({ onLoginSuccess }) {
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Form states
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Status states
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Xử lý gửi biểu mẫu (Đăng nhập / Đăng ký)
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (isRegisterMode) {
      // UC-01: Đăng ký
      if (!fullName.trim() || !email.trim() || !password || !confirmPassword) {
        setErrorMessage('Vui lòng điền đầy đủ tất cả các trường thông tin.');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMessage('Mật khẩu và xác nhận mật khẩu không trùng khớp.');
        return;
      }

      try {
        setLoading(true);
        const res = await axios.post('/api/auth/register', {
          fullName: fullName.trim(),
          email: email.trim(),
          password,
          confirmPassword
        });

        if (res.data?.success) {
          setSuccessMessage('Đăng ký tài khoản thành công! Bạn có thể đăng nhập ngay.');
          setIsRegisterMode(false);
          setPassword('');
          setConfirmPassword('');
        }
      } catch (err) {
        setErrorMessage(err.response?.data?.message || 'Đăng ký không thành công.');
      } finally {
        setLoading(false);
      }

    } else {
      // UC-02: Đăng nhập
      if (!email.trim() || !password) {
        setErrorMessage('Vui lòng nhập đầy đủ Email và Mật khẩu.');
        return;
      }

      try {
        setLoading(true);
        const res = await axios.post('/api/auth/login', {
          email: email.trim(),
          password
        });

        if (res.data?.success) {
          const { token, user } = res.data.data;
          // Lưu phiên đăng nhập
          localStorage.setItem('agro_token', token);
          localStorage.setItem('agro_user', JSON.stringify(user));
          axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

          onLoginSuccess(user);
        }
      } catch (err) {
        setErrorMessage(err.response?.data?.message || 'Đăng nhập không thành công.');
      } finally {
        setLoading(false);
      }
    }
  };

  // Nút đăng nhập nhanh tài khoản mẫu
  const handleQuickLogin = (quickEmail, quickPassword) => {
    setEmail(quickEmail);
    setPassword(quickPassword);
    setErrorMessage('');
    setSuccessMessage('');
    setIsRegisterMode(false);
  };

  return (
    <div className="min-h-screen bg-[#F7F9F7] flex flex-col justify-center items-center p-4 antialiased selection:bg-[#27864B] selection:text-white">
      {/* Container Thẻ Đăng Nhập */}
      <div className="w-full max-w-md bg-white border border-[#E5EBE6] rounded-2xl shadow-dropdown p-8 space-y-6">
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center space-y-2">
          <BrandLogo size={42} />
          <h2 className="text-xl font-bold text-[#202B24] tracking-tight pt-2">
            {isRegisterMode ? 'Đăng Ký Tài Khoản Nông Dân' : 'Đăng Nhập Hệ Thống'}
          </h2>
          <p className="text-xs text-[#718078] max-w-xs">
            {isRegisterMode 
              ? 'Tạo tài khoản để quản lý trạm quan trắc đất và nhận tư vấn liều lượng bón phân NPK.'
              : 'Nền tảng IoT giám sát đa chế độ chất lượng đất & Hỗ trợ tối ưu phân bón nông nghiệp.'}
          </p>
        </div>

        {/* Thông báo Lỗi / Thành công */}
        {errorMessage && (
          <div className="p-3.5 bg-[#FCECEC] border border-[#F8D2D2] rounded-xl text-xs text-[#DC6262] flex items-start gap-2.5 animate-in fade-in-50">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3.5 bg-[#EAF4EC] border border-[#CDE5D4] rounded-xl text-xs text-[#27864B] flex items-start gap-2.5 animate-in fade-in-50">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{successMessage}</span>
          </div>
        )}

        {/* Form Đăng nhập / Đăng ký */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegisterMode && (
            <div>
              <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                Họ và tên <span className="text-[#DC6262]">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9CAAA2]" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ví dụ: Nguyễn Văn Nông Dân"
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
              Địa chỉ Email <span className="text-[#DC6262]">*</span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9CAAA2]" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
              Mật khẩu <span className="text-[#DC6262]">*</span>
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9CAAA2]" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Tối thiểu 6 ký tự..."
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-xl pl-10 pr-10 py-2.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#9CAAA2] hover:text-[#202B24]"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {isRegisterMode && (
            <div>
              <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                Xác nhận lại mật khẩu <span className="text-[#DC6262]">*</span>
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9CAAA2]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Nhập lại mật khẩu giống ở trên..."
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold py-3 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
          >
            {loading ? (
              <span>Đang xử lý...</span>
            ) : (
              <>
                <span>{isRegisterMode ? 'Đăng Ký Tài Khoản' : 'Đăng Nhập'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Chuyển đổi giữa Đăng nhập và Đăng ký */}
        <div className="pt-2 text-center text-xs text-[#718078] border-t border-[#F2F5F3]">
          {isRegisterMode ? (
            <div>
              Đã có tài khoản?{' '}
              <button
                type="button"
                onClick={() => { setIsRegisterMode(false); setErrorMessage(''); setSuccessMessage(''); }}
                className="text-[#27864B] font-semibold hover:underline"
              >
                Đăng nhập ngay
              </button>
            </div>
          ) : (
            <div>
              Chưa có tài khoản?{' '}
              <button
                type="button"
                onClick={() => { setIsRegisterMode(true); setErrorMessage(''); setSuccessMessage(''); }}
                className="text-[#27864B] font-semibold hover:underline"
              >
                Đăng ký tài khoản mới
              </button>
            </div>
          )}
        </div>

        {/* Khối Đăng Nhập Nhanh Theo Tài Khoản Hệ Thống */}
        <div className="p-3.5 bg-[#FAFCFA] border border-[#E5EBE6] rounded-xl space-y-2">
          <div className="text-[11px] font-semibold text-[#718078] uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#27864B]" />
            <span>Đăng nhập nhanh để kiểm thử</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleQuickLogin('user@gmail.com', 'user123')}
              className="p-2 rounded-lg border border-[#E5EBE6] bg-white hover:bg-[#F2F5F3] text-left transition-colors"
            >
              <div className="font-semibold text-[#202B24] text-[11px]">Nông Dân (User)</div>
              <div className="text-[10px] text-[#718078] font-mono mt-0.5 truncate">user@gmail.com</div>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('admin@gmail.com', 'admin123')}
              className="p-2 rounded-lg border border-[#E5EBE6] bg-white hover:bg-[#F2F5F3] text-left transition-colors"
            >
              <div className="font-semibold text-[#202B24] text-[11px]">Quản Trị Viên (Admin)</div>
              <div className="text-[10px] text-[#718078] font-mono mt-0.5 truncate">admin@gmail.com</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
