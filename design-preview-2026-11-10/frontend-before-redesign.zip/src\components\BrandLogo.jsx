import React from 'react';

export default function BrandLogo({ size = 32, collapsed = false }) {
  return (
    <div className="flex items-center gap-2.5 select-none">
      {/* Precision Agronomy SVG Mark */}
      <div 
        className="flex items-center justify-center rounded-xl bg-[#27864B] text-white shadow-sm shrink-0"
        style={{ width: size, height: size }}
      >
        <svg 
          viewBox="0 0 24 24" 
          fill="none" 
          className="w-5 h-5"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Stem & Ground line */}
          <path 
            d="M12 21V11" 
            stroke="currentColor" 
            strokeWidth="2.2" 
            strokeLinecap="round" 
          />
          {/* Left bio leaf */}
          <path 
            d="M12 15C8.5 15 5.5 12.5 5.5 8.5C9.5 8.5 12 11 12 15Z" 
            fill="currentColor" 
            fillOpacity="0.88" 
          />
          {/* Right precision node loop */}
          <path 
            d="M12 11C15 11 18.5 9 18.5 5C14.5 5 12 7.5 12 11Z" 
            fill="currentColor" 
            fillOpacity="0.95" 
          />
          {/* Sensor probe wave arc */}
          <circle 
            cx="12" 
            cy="4" 
            r="1.6" 
            fill="currentColor" 
          />
        </svg>
      </div>

      {/* Wordmark */}
      {!collapsed && (
        <div className="flex flex-col leading-tight">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-[15px] tracking-tight text-[#202B24]">
              AgroPrecision
            </span>
            <span className="text-[10px] font-semibold tracking-wide uppercase px-1.5 py-0.5 rounded bg-[#EAF4EC] text-[#27864B] border border-[#CDE5D4]">
              IoT
            </span>
          </div>
          <span className="text-[11px] font-medium text-[#718078] tracking-tight">
            Soil Telemetry & Analytics
          </span>
        </div>
      )}
    </div>
  );
}
