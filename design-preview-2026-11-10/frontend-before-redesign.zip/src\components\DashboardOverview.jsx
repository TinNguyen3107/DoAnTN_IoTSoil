import React from 'react';
import { 
  Radio, 
  Smartphone, 
  Layers, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  ArrowUpRight,
  Plus,
  ShieldCheck,
  Clock,
  Sparkles
} from 'lucide-react';

export default function DashboardOverview({ 
  devices = [], 
  unreadAlerts = 0, 
  onNavigateToDevices, 
  onNavigateToAlerts 
}) {
  const fixedCount = devices.filter(d => d.type === 'fixed').length;
  const handheldCount = devices.filter(d => d.type === 'handheld').length;
  const activeCount = devices.filter(d => d.is_active).length;
  const totalReadings = devices.reduce((sum, d) => sum + (d.total_readings || 0), 0);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Tổng quan Hệ thống Quan trắc
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Theo dõi tình trạng hoạt động của mạng lưới trạm đo đa chế độ và số liệu chất lượng đất thực địa.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onNavigateToDevices}
            className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Trạm Quan Trắc</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row (Clean, subtle borders, high clarity) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Tổng trạm */}
        <div className="bg-white border border-[#E5EBE6] rounded-card p-4 hover:border-[#D0D9D2] transition-colors shadow-subtle">
          <div className="flex items-center justify-between text-xs text-[#718078] font-medium">
            <span>Tổng số trạm đo</span>
            <div className="w-8 h-8 rounded-lg bg-[#EAF4EC] text-[#27864B] flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#202B24] mono-tabular">
              {devices.length}
            </span>
            <span className="text-[11px] text-[#718078]">trạm đã đăng ký</span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-[#F2F5F3] flex items-center justify-between text-[11px] text-[#718078]">
            <span>Cố định: <strong className="text-[#202B24] font-semibold">{fixedCount}</strong></span>
            <span>Cầm tay: <strong className="text-[#202B24] font-semibold">{handheldCount}</strong></span>
          </div>
        </div>

        {/* Card 2: Thiết bị hoạt động */}
        <div className="bg-white border border-[#E5EBE6] rounded-card p-4 hover:border-[#D0D9D2] transition-colors shadow-subtle">
          <div className="flex items-center justify-between text-xs text-[#718078] font-medium">
            <span>Thiết bị đang hoạt động</span>
            <div className="w-8 h-8 rounded-lg bg-[#E8F5EE] text-[#26965A] flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#26965A] mono-tabular">
              {activeCount} / {devices.length}
            </span>
            <span className="text-[11px] text-[#718078]">sẵn sàng nhận dữ liệu</span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-[#F2F5F3] flex items-center gap-1.5 text-[11px] text-[#26965A]">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            <span>Xác thực qua API Key SHA-256</span>
          </div>
        </div>

        {/* Card 3: Bản ghi thổ nhưỡng */}
        <div className="bg-white border border-[#E5EBE6] rounded-card p-4 hover:border-[#D0D9D2] transition-colors shadow-subtle">
          <div className="flex items-center justify-between text-xs text-[#718078] font-medium">
            <span>Dữ liệu đo đạc tích lũy</span>
            <div className="w-8 h-8 rounded-lg bg-[#EBF3FA] text-[#4387C5] flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#202B24] mono-tabular">
              {totalReadings}
            </span>
            <span className="text-[11px] text-[#718078]">bản ghi 7 thông số</span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-[#F2F5F3] text-[11px] text-[#718078] flex items-center justify-between">
            <span>Lưu trữ: MySQL 8.0</span>
            <span className="text-[#4387C5] font-medium">Tự động + Thủ công</span>
          </div>
        </div>

        {/* Card 4: Tình trạng cảnh báo */}
        <div 
          onClick={unreadAlerts > 0 ? onNavigateToAlerts : undefined}
          className={`bg-white border rounded-card p-4 transition-colors shadow-subtle ${
            unreadAlerts > 0 
              ? 'border-[#F8D2D2] hover:border-[#DC6262] cursor-pointer' 
              : 'border-[#E5EBE6] hover:border-[#D0D9D2]'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-[#718078] font-medium">
            <span>Cảnh báo vi phạm ngưỡng</span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              unreadAlerts > 0 
                ? 'bg-[#FCECEC] text-[#DC6262]' 
                : 'bg-[#EAF4EC] text-[#26965A]'
            }`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl font-bold mono-tabular ${
              unreadAlerts > 0 ? 'text-[#DC6262]' : 'text-[#202B24]'
            }`}>
              {unreadAlerts}
            </span>
            <span className="text-[11px] text-[#718078]">cảnh báo chưa xử lý</span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-[#F2F5F3] text-[11px] flex items-center justify-between">
            {unreadAlerts > 0 ? (
              <span className="text-[#DC6262] font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Nhấn để kiểm tra & xử lý</span>
              </span>
            ) : (
              <span className="text-[#718078] flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#26965A]" />
                <span>Ngưỡng tham chiếu ổn định</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid: Telemetry Parameters & Hardware Station Quickview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): 7 Sensor Parameter Reference Strip */}
        <div className="lg:col-span-2 bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
          <div className="flex items-center justify-between border-b border-[#E5EBE6] pb-3">
            <div>
              <h2 className="text-sm font-bold text-[#202B24] tracking-tight">
                Dải Đo Tham Chiếu 7 Thông Số Thổ Nhưỡng
              </h2>
              <p className="text-[11px] text-[#718078] mt-0.5">
                Các chỉ số cảm biến NPK 7-in-1 giao tiếp RS485 Modbus RTU được hệ thống tự động kiểm soát.
              </p>
            </div>
            <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-[#F2F5F3] text-[#718078]">
              Chuẩn TCVN
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {/* Đạm (N) */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#0284C7] flex items-center justify-between">
                <span>Đạm (N)</span>
                <span className="text-[10px] font-mono text-[#718078]">mg/kg</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">50 – 150</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Khoảng tối ưu thân lá</div>
            </div>

            {/* Lân (P) */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#EA580C] flex items-center justify-between">
                <span>Lân (P)</span>
                <span className="text-[10px] font-mono text-[#718078]">mg/kg</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">30 – 80</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Kích thích phát triển rễ</div>
            </div>

            {/* Kali (K) */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#7C3AED] flex items-center justify-between">
                <span>Kali (K)</span>
                <span className="text-[10px] font-mono text-[#718078]">mg/kg</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">80 – 200</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Cứng cây, chống hạn mặn</div>
            </div>

            {/* Độ chua pH */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#2563EB] flex items-center justify-between">
                <span>Độ chua (pH)</span>
                <span className="text-[10px] font-mono text-[#718078]">Scale</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">5.5 – 7.0</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Môi trường hấp thu tốt</div>
            </div>

            {/* Độ dẫn điện EC */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#D97706] flex items-center justify-between">
                <span>Độ dẫn (EC)</span>
                <span className="text-[10px] font-mono text-[#718078]">µS/cm</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">300 – 1200</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Kiểm soát nồng độ muối</div>
            </div>

            {/* Nhiệt độ */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#E11D48] flex items-center justify-between">
                <span>Nhiệt độ</span>
                <span className="text-[10px] font-mono text-[#718078]">°C</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">18.0 – 35.0</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Vùng vi sinh vật có lợi</div>
            </div>

            {/* Độ ẩm */}
            <div className="p-3 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA]">
              <div className="text-[11px] font-semibold text-[#0D9488] flex items-center justify-between">
                <span>Độ ẩm đất</span>
                <span className="text-[10px] font-mono text-[#718078]">%</span>
              </div>
              <div className="mt-1 text-base font-bold text-[#202B24] mono-tabular">50.0 – 80.0</div>
              <div className="text-[10px] text-[#718078] mt-0.5">Cân bằng ẩm tầng canh tác</div>
            </div>
          </div>
        </div>

        {/* Right Column (1 col): Hardware Architecture & Mode breakdown */}
        <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
          <div className="border-b border-[#E5EBE6] pb-3">
            <h2 className="text-sm font-bold text-[#202B24] tracking-tight">
              Cấu Trúc Thu Thập Đa Chế Độ
            </h2>
            <p className="text-[11px] text-[#718078] mt-0.5">
              Phân tách 2 phương thức đo độc lập theo thiết kế.
            </p>
          </div>

          <div className="space-y-3">
            <div className="p-3.5 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA] flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#EBF3FA] text-[#4387C5] flex items-center justify-center shrink-0">
                <Radio className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <div className="font-semibold text-[#202B24] flex items-center gap-1.5">
                  <span>Trạm cố định (ESP32-S3)</span>
                  <span className="text-[10px] font-mono text-[#4387C5] bg-[#EBF3FA] px-1.5 py-0.2 rounded">NTP</span>
                </div>
                <p className="text-[11px] text-[#718078] mt-1 leading-relaxed">
                  Tự động thức dậy vào 8:00 sáng & 16:00 chiều, gửi gói tin HTTPS POST rồi về chế độ Deep Sleep.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-[#E5EBE6] bg-[#FAFCFA] flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#FDF6E9] text-[#E9A23B] flex items-center justify-center shrink-0">
                <Smartphone className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <div className="font-semibold text-[#202B24] flex items-center gap-1.5">
                  <span>Thiết bị cầm tay dã ngoại</span>
                  <span className="text-[10px] font-mono text-[#E9A23B] bg-[#FDF6E9] px-1.5 py-0.2 rounded">Manual</span>
                </div>
                <p className="text-[11px] text-[#718078] mt-1 leading-relaxed">
                  Cắm trực tiếp, nhấn nút cơ học, xem tức thời trên OLED và đồng bộ về máy chủ qua Wi-Fi khi có sóng.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onNavigateToDevices}
              className="w-full py-2 px-3 rounded-lg border border-[#E5EBE6] hover:bg-[#F2F5F3] text-xs font-semibold text-[#202B24] flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Quản lý danh sách trạm đo ({devices.length})</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#718078]" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
