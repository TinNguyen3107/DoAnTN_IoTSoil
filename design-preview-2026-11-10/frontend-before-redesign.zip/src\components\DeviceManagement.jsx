import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Radio, 
  Smartphone, 
  Key, 
  Plus, 
  RefreshCw, 
  ShieldCheck, 
  Copy, 
  Check, 
  AlertTriangle, 
  Activity, 
  Power,
  Trash2,
  Lock,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  X
} from 'lucide-react';

export default function DeviceManagement({ currentUser, onDevicesChanged }) {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  // Modals state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [revealedKey, setRevealedKey] = useState({ deviceName: '', key: '', isNew: false });
  const [copied, setCopied] = useState(false);

  // Form state
  const [name, setName] = useState('');
  const [type, setType] = useState('fixed');
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Tải danh sách thiết bị theo đúng phân quyền tài khoản
  const fetchDevices = async () => {
    try {
      setLoading(true);
      const url = currentUser?.role === 'admin'
        ? '/api/devices'
        : `/api/devices?ownerId=${currentUser?.id}`;
      const res = await axios.get(url);
      if (res.data?.success) {
        setDevices(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi tải danh sách trạm đo:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser) {
      fetchDevices();
    }
  }, [currentUser?.id, currentUser?.role]);

  // Xử lý tạo trạm đo mới (UC-03)
  const handleCreateDevice = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Vui lòng nhập tên nhận diện cho trạm đo.');
      return;
    }
    setFormError('');
    setSubmitting(true);

    try {
      const res = await axios.post('/api/devices', {
        name: name.trim(),
        type,
        ownerId: currentUser?.id || 1
      });

      if (res.data?.success) {
        setShowCreateModal(false);
        setName('');
        setType('fixed');
        setRevealedKey({
          deviceName: res.data.data.device.name,
          key: res.data.data.apiKey,
          isNew: true
        });
        setShowKeyModal(true);
        fetchDevices();
        onDevicesChanged?.();
      }
    } catch (err) {
      setFormError(err.response?.data?.message || 'Có lỗi xảy ra khi tạo trạm đo.');
    } finally {
      setSubmitting(false);
    }
  };

  // Cấp lại API Key (UC-04: Cấp lại khóa & vô hiệu hóa khóa cũ)
  const handleRegenerateKey = async (deviceId, deviceName) => {
    if (!window.confirm(`⚠️ CẢNH BÁO BẢO MẬT:\nCấp lại khóa cho trạm "${deviceName}" sẽ VÔ HIỆU HÓA NGAY LẬP TỨC API Key hiện tại trên vi điều khiển ESP32!\n\nBạn có chắc chắn muốn phát hành chuỗi khóa mới?`)) {
      return;
    }

    try {
      const res = await axios.post(`/api/devices/${deviceId}/regenerate-key`);
      if (res.data?.success) {
        setRevealedKey({
          deviceName: res.data.data.deviceName,
          key: res.data.data.newApiKey,
          isNew: false
        });
        setShowKeyModal(true);
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Không thể cấp lại API Key.');
    }
  };

  // Bật/tắt trạng thái hoạt động
  const handleToggleStatus = async (deviceId, currentStatus) => {
    try {
      await axios.patch(`/api/devices/${deviceId}/status`, {
        isActive: !currentStatus
      });
      fetchDevices();
      onDevicesChanged?.();
    } catch (err) {
      alert('Lỗi cập nhật trạng thái trạm đo.');
    }
  };

  // Xóa trạm đo
  const handleDeleteDevice = async (deviceId, deviceName) => {
    if (!window.confirm(`Xác nhận xóa trạm đo "${deviceName}"?\nThao tác này sẽ gỡ bỏ trạm khỏi hệ thống và không thể hoàn tác.`)) {
      return;
    }
    try {
      await axios.delete(`/api/devices/${deviceId}`);
      fetchDevices();
      onDevicesChanged?.();
    } catch (err) {
      alert('Lỗi khi xóa thiết bị.');
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(revealedKey.key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Lọc thiết bị theo tìm kiếm & loại
  const filteredDevices = devices.filter((d) => {
    const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || d.type === typeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Page Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Quản Lý Trạm Đo & Khóa Thiết Bị
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Đăng ký định danh phần cứng, phân loại trạm thu thập và cấp phát mã API Key bảo mật cho vi điều khiển ESP32.
          </p>
        </div>

        <button
          onClick={() => { setShowCreateModal(true); setFormError(''); }}
          className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Thêm Trạm Đo Mới</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-3 shadow-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9CAAA2]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm theo tên trạm đo hoặc vị trí lô đất..."
            className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg pl-9 pr-3.5 py-1.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <div className="inline-flex p-0.5 rounded-lg bg-[#F7F9F7] border border-[#E5EBE6] text-xs">
            <button
              onClick={() => setTypeFilter('all')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                typeFilter === 'all'
                  ? 'bg-white text-[#202B24] shadow-xs'
                  : 'text-[#718078] hover:text-[#202B24]'
              }`}
            >
              Tất cả ({devices.length})
            </button>
            <button
              onClick={() => setTypeFilter('fixed')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                typeFilter === 'fixed'
                  ? 'bg-white text-[#4387C5] shadow-xs'
                  : 'text-[#718078] hover:text-[#202B24]'
              }`}
            >
              Cố định ({devices.filter(d => d.type === 'fixed').length})
            </button>
            <button
              onClick={() => setTypeFilter('handheld')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                typeFilter === 'handheld'
                  ? 'bg-white text-[#D97706] shadow-xs'
                  : 'text-[#718078] hover:text-[#202B24]'
              }`}
            >
              Cầm tay ({devices.filter(d => d.type === 'handheld').length})
            </button>
          </div>

          <button
            onClick={fetchDevices}
            disabled={loading}
            className="p-1.5 rounded-lg border border-[#E5EBE6] text-[#718078] hover:text-[#202B24] hover:bg-[#F2F5F3] transition-colors"
            title="Làm mới danh sách"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#27864B]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white border border-[#E5EBE6] rounded-card shadow-subtle overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-xs text-[#718078]">
            <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
            Đang tải dữ liệu trạm quan trắc từ máy chủ...
          </div>
        ) : filteredDevices.length === 0 ? (
          <div className="py-16 text-center px-4">
            <Radio className="w-8 h-8 text-[#9CAAA2] mx-auto mb-2 stroke-[1.5]" />
            <div className="text-sm font-semibold text-[#202B24]">
              {searchQuery ? 'Không tìm thấy trạm đo phù hợp' : 'Chưa có trạm đo nào được đăng ký'}
            </div>
            <div className="text-xs text-[#718078] mt-1 max-w-sm mx-auto">
              {searchQuery 
                ? 'Thử thay đổi từ khóa tìm kiếm hoặc bỏ bộ lọc để xem toàn bộ danh mục.'
                : 'Bấm nút "Thêm Trạm Đo Mới" để khai báo thiết bị và nhận mã khóa API Key đầu tiên.'}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAFCFA] border-b border-[#E5EBE6] text-[#718078] font-semibold">
                <tr>
                  <th className="py-3 px-4 w-16">MÃ TRẠM</th>
                  <th className="py-3 px-4">TÊN TRẠM & VỊ TRÍ CANH TÁC</th>
                  <th className="py-3 px-4">PHƯƠNG THỨC THU THẬP</th>
                  <th className="py-3 px-4">TRẠNG THÁI</th>
                  <th className="py-3 px-4">TỔNG SỐ ĐO</th>
                  <th className="py-3 px-4">LẦN GỬI CUỐI</th>
                  <th className="py-3 px-4 text-right">THAO TÁC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5EBE6] text-[#202B24]">
                {filteredDevices.map((device) => (
                  <tr key={device.id} className="hover:bg-[#F9FBFA] transition-colors">
                    {/* Device ID */}
                    <td className="py-3.5 px-4 font-mono font-semibold text-[#718078]">
                      #{String(device.id).padStart(3, '0')}
                    </td>

                    {/* Name */}
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-[#202B24]">{device.name}</div>
                      <div className="text-[11px] text-[#718078] mt-0.5">
                        Chủ sở hữu: {device.owner_name || 'Quản trị viên'}
                      </div>
                    </td>

                    {/* Hardware Ingestion Mode */}
                    <td className="py-3.5 px-4">
                      {device.type === 'fixed' ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-[#EBF3FA] text-[#2563EB] border border-[#CFE3F5]">
                          <Radio className="w-3 h-3" />
                          Trạm Cố Định (NTP)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-[#FDF6E9] text-[#D97706] border border-[#F6DEB5]">
                          <Smartphone className="w-3 h-3" />
                          Máy Cầm Tay (Manual)
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      {device.is_active ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-[#EAF4EC] text-[#27864B] border border-[#CDE5D4]">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#27864B]"></span>
                          Hoạt động
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-[#FCECEC] text-[#DC6262] border border-[#F8D2D2]">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#DC6262]"></span>
                          Tạm khóa
                        </span>
                      )}
                    </td>

                    {/* Total Readings */}
                    <td className="py-3.5 px-4 font-mono text-[#718078]">
                      <span className="font-semibold text-[#202B24]">{device.total_readings || 0}</span> bản ghi
                    </td>

                    {/* Last Online */}
                    <td className="py-3.5 px-4 font-mono text-[11px] text-[#718078]">
                      {device.last_online 
                        ? new Date(device.last_online).toLocaleString('vi-VN', { 
                            hour: '2-digit', 
                            minute: '2-digit', 
                            day: '2-digit', 
                            month: '2-digit', 
                            year: 'numeric' 
                          }) 
                        : 'Chưa có dữ liệu'}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right space-x-1.5">
                      <button
                        onClick={() => handleRegenerateKey(device.id, device.name)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#E5EBE6] hover:bg-[#F2F5F3] text-[#202B24] text-[11px] font-medium transition-colors"
                        title="Cấp lại API Key (vô hiệu hóa khóa cũ)"
                      >
                        <Key className="w-3.5 h-3.5 text-[#D97706]" />
                        <span>Cấp lại Key</span>
                      </button>

                      <button
                        onClick={() => handleToggleStatus(device.id, device.is_active)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-medium border transition-colors ${
                          device.is_active 
                            ? 'border-[#F8D2D2] text-[#DC6262] hover:bg-[#FCECEC]' 
                            : 'border-[#CDE5D4] text-[#27864B] hover:bg-[#EAF4EC]'
                        }`}
                        title={device.is_active ? "Tạm ngưng nhận dữ liệu từ trạm này" : "Kích hoạt lại trạm"}
                      >
                        <Power className="w-3 h-3" />
                        <span>{device.is_active ? 'Khóa' : 'Kích hoạt'}</span>
                      </button>

                      <button
                        onClick={() => handleDeleteDevice(device.id, device.name)}
                        className="p-1.5 rounded-lg text-[#9CAAA2] hover:text-[#DC6262] hover:bg-[#FCECEC] transition-colors"
                        title="Xóa trạm đo"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL 1: Đăng ký trạm đo mới (UC-03) */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in-50">
          <div className="bg-white border border-[#E5EBE6] rounded-2xl w-full max-w-md p-6 shadow-modal space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5EBE6]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#EAF4EC] text-[#27864B] flex items-center justify-center">
                  <Radio className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-[#202B24]">Đăng Ký Trạm Quan Trắc Mới</h3>
                  <p className="text-[11px] text-[#718078]">Khai báo phần cứng để kết nối vào nền tảng</p>
                </div>
              </div>
              <button 
                onClick={() => setShowCreateModal(false)}
                className="text-[#9CAAA2] hover:text-[#202B24] p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateDevice} className="space-y-4">
              {formError && (
                <div className="p-3 bg-[#FCECEC] border border-[#F8D2D2] rounded-lg text-[#DC6262] text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Tên trạm đo / Lô đất canh tác <span className="text-[#DC6262]">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ví dụ: Trạm Ruộng Lúa Lô 3B, Máy Đo Cầm Tay Dã Ngoại..."
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3.5 py-2 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Phân loại thiết bị phần cứng <span className="text-[#DC6262]">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setType('fixed')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      type === 'fixed'
                        ? 'bg-[#EBF3FA] border-[#4387C5] text-[#1E40AF] ring-1 ring-[#4387C5]'
                        : 'bg-[#F7F9F7] border-[#E5EBE6] text-[#718078] hover:border-[#D0D9D2]'
                    }`}
                  >
                    <Radio className="w-4 h-4 mb-1 text-[#2563EB]" />
                    <div className="font-semibold text-xs text-[#202B24]">Trạm Cố Định</div>
                    <div className="text-[10px] text-[#718078] mt-0.5">Đo tự động theo lịch NTP (8h & 16h), ngủ sâu</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setType('handheld')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      type === 'handheld'
                        ? 'bg-[#FDF6E9] border-[#D97706] text-[#B45309] ring-1 ring-[#D97706]'
                        : 'bg-[#F7F9F7] border-[#E5EBE6] text-[#718078] hover:border-[#D0D9D2]'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mb-1 text-[#D97706]" />
                    <div className="font-semibold text-xs text-[#202B24]">Thiết Bị Cầm Tay</div>
                    <div className="text-[10px] text-[#718078] mt-0.5">Khảo sát dã ngoại ngẫu nhiên, nút bấm cơ</div>
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-[#E5EBE6] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs font-medium text-[#718078] hover:text-[#202B24]"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors disabled:opacity-50 shadow-xs"
                >
                  {submitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Đang tạo...</span>
                    </>
                  ) : (
                    <>
                      <Key className="w-3.5 h-3.5" />
                      <span>Tạo & Cấp Mã API Key</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Hiển thị API Key bản rõ (UC-04: Hiển thị 1 lần duy nhất) */}
      {showKeyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in-50">
          <div className="bg-white border border-[#E5EBE6] rounded-2xl w-full max-w-lg p-6 shadow-modal space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FDF6E9] text-[#D97706] flex items-center justify-center shrink-0 border border-[#F6DEB5]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-[#202B24]">
                  {revealedKey.isNew ? 'Đăng Ký Thành Công — Cấp Khóa API' : 'Phát Hành Khóa API Mới'}
                </h3>
                <p className="text-xs text-[#718078]">
                  Trạm quan trắc: <strong className="text-[#202B24] font-semibold">{revealedKey.deviceName}</strong>
                </p>
              </div>
            </div>

            {/* Security Warning Box */}
            <div className="p-3.5 bg-[#FFFBEB] border border-[#FEE685] rounded-xl text-xs text-[#8C5810] space-y-1">
              <div className="font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-[#D97706]" />
                <span>Quy tắc bảo mật thiết bị IoT:</span>
              </div>
              <p className="text-[11px] leading-relaxed text-[#92400E]">
                Chuỗi khóa bản rõ dưới đây <strong>chỉ hiển thị duy nhất 1 lần</strong>. 
                Máy chủ chỉ lưu trữ mã băm SHA-256. Hãy sao chép ngay chuỗi khóa và nạp vào cấu hình mã nguồn vi điều khiển ESP32.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#718078] mb-1.5 uppercase tracking-wide">
                MÃ KHÓA API KEY CỦA THIẾT BỊ:
              </label>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3.5 py-2.5 text-xs font-mono font-semibold text-[#202B24] tracking-wider break-all select-all">
                  {revealedKey.key}
                </div>
                <button
                  onClick={copyToClipboard}
                  className={`px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${
                    copied 
                      ? 'bg-[#27864B] text-white' 
                      : 'bg-white border border-[#E5EBE6] text-[#202B24] hover:bg-[#F2F5F3]'
                  }`}
                  title="Sao chép vào bộ nhớ đệm"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4 text-[#718078]" />}
                  <span>{copied ? 'Đã sao chép' : 'Sao chép'}</span>
                </button>
              </div>
            </div>

            <div className="pt-3 border-t border-[#E5EBE6] flex items-center justify-end">
              <button
                onClick={() => setShowKeyModal(false)}
                className="bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs"
              >
                Tôi Đã Lưu Khóa, Đóng Cửa Sổ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
