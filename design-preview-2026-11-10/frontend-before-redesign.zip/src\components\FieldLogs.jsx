import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  ClipboardList, 
  Plus, 
  Calendar, 
  Trash2, 
  RefreshCw, 
  Filter, 
  Radio, 
  Smartphone,
  Sprout,
  CheckCircle2,
  AlertCircle,
  X,
  Droplets,
  Sparkles
} from 'lucide-react';

export default function FieldLogs({ devices = [] }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedStationFilter, setSelectedStationFilter] = useState('all');

  // Trạng thái Modal thêm sự kiện
  const [showAddModal, setShowAddModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [modalError, setModalError] = useState('');

  // Form Fields
  const [formDeviceId, setFormDeviceId] = useState('');
  const [formEventType, setFormEventType] = useState('Bón thúc');
  const [formAmount, setFormAmount] = useState('');
  const [formUnit, setFormUnit] = useState('kg/sào');
  const [formDate, setFormDate] = useState(new Date().toISOString().slice(0, 10));
  const [formNotes, setFormNotes] = useState('');

  // Tải danh sách sự kiện canh tác (UC-14 Step 2 & 3)
  const fetchEvents = async () => {
    try {
      setLoading(true);
      const url = selectedStationFilter === 'all' 
        ? '/api/field-events' 
        : `/api/field-events?deviceId=${selectedStationFilter}`;
      
      const res = await axios.get(url);
      if (res.data?.success) {
        setEvents(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi tải nhật ký canh tác:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, [selectedStationFilter]);

  // Khởi tạo / đồng bộ trạm mặc định cho form
  useEffect(() => {
    if (devices.length > 0) {
      const exists = devices.some(d => String(d.id) === String(formDeviceId));
      if (!formDeviceId || !exists) {
        setFormDeviceId(String(devices[0].id));
      }
    } else {
      setFormDeviceId('');
    }
  }, [devices]);

  // Xử lý Thêm sự kiện canh tác mới (UC-14 Step 6, 7, 8, 9, 10)
  const handleCreateEvent = async (e) => {
    e.preventDefault();
    setModalError('');

    // Kiểm tra tính hợp lệ cơ bản
    if (!formDeviceId) {
      setModalError('Vui lòng chọn trạm đo / vị trí lô đất áp dụng.');
      return;
    }
    if (!formAmount || parseFloat(formAmount) <= 0) {
      setModalError('Liều lượng phải là một số lớn hơn 0.');
      return;
    }

    // UC-14 Alt 6a: Kiểm tra ngày thực hiện không ở tương lai
    const today = new Date().toISOString().slice(0, 10);
    if (formDate > today) {
      setModalError('Ngày thực hiện canh tác không hợp lệ: Không được chọn mốc thời gian ở tương lai.');
      return;
    }

    try {
      setSubmitting(true);
      const payload = {
        deviceId: Number(formDeviceId),
        eventType: formEventType,
        amount: parseFloat(formAmount),
        unit: formUnit,
        eventDate: formDate,
        notes: formNotes
      };

      const res = await axios.post('/api/field-events', payload);
      if (res.data?.success) {
        setShowAddModal(false);
        // Reset form
        setFormAmount('');
        setFormNotes('');
        setFormDate(new Date().toISOString().slice(0, 10));
        fetchEvents();
      }
    } catch (err) {
      setModalError(err.response?.data?.message || 'Có lỗi xảy ra khi lưu sự kiện canh tác.');
    } finally {
      setSubmitting(false);
    }
  };

  // UC-14 Alt 5a: Xóa sự kiện canh tác nhập sai
  const handleDeleteEvent = async (id, eventType, date) => {
    if (!window.confirm(`Xác nhận xóa sự kiện "${eventType}" ngày ${date}?\nThao tác này sẽ gỡ bỏ cọc mốc tương ứng trên biểu đồ lịch sử biến thiên.`)) {
      return;
    }

    try {
      const res = await axios.delete(`/api/field-events/${id}`);
      if (res.data?.success) {
        fetchEvents();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi khi xóa sự kiện.');
    }
  };

  // Phân loại màu sắc badge can thiệp nông học
  const getBadgeStyle = (type) => {
    if (type.includes('Bón vôi') || type.includes('Khử chua')) {
      return 'bg-[#FFF8E6] text-[#D97706] border-[#FDE68A]';
    }
    if (type.includes('Rửa mặn') || type.includes('Tưới')) {
      return 'bg-[#EFF6FF] text-[#2563EB] border-[#BFDBFE]';
    }
    if (type.includes('Bón lót')) {
      return 'bg-[#F3F4F6] text-[#4B5563] border-[#E5E7EB]';
    }
    return 'bg-[#EAF4EC] text-[#27864B] border-[#CDE5D4]';
  };

  return (
    <div className="space-y-6">
      {/* Tiêu đề trang & Nút thêm sự kiện */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Sổ Nhật Ký Canh Tác & Bón Phân
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Ghi nhận các can thiệp nông học (bón lót, bón thúc, khử chua, tưới tiêu) để tự động đồng bộ cọc mốc lên đồ thị dinh dưỡng đất.
          </p>
        </div>

        <button
          onClick={() => { setShowAddModal(true); setModalError(''); }}
          className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Thêm Sự Kiện Canh Tác</span>
        </button>
      </div>

      {/* Thanh lọc theo trạm đo */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-3 shadow-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs w-full sm:w-auto">
          <Filter className="w-4 h-4 text-[#9CAAA2]" />
          <span className="font-semibold text-[#718078]">Lọc theo trạm:</span>
          <select
            value={selectedStationFilter}
            onChange={(e) => setSelectedStationFilter(e.target.value)}
            className="bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-1.5 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
          >
            <option value="all">Tất cả các trạm ({devices.length} trạm)</option>
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.type === 'fixed' ? 'Cố định' : 'Cầm tay'})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-[#718078] font-mono">
            Tổng cộng: <strong>{events.length}</strong> đợt can thiệp
          </span>
          <button
            onClick={fetchEvents}
            className="p-1.5 rounded-lg border border-[#E5EBE6] hover:bg-[#F2F5F3] text-[#718078] transition-colors"
            title="Làm mới"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#27864B]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Bảng Danh Sách Nhật Ký */}
      <div className="bg-white border border-[#E5EBE6] rounded-card shadow-subtle overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-xs text-[#718078]">
            <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
            Đang tải dữ liệu nhật ký canh tác...
          </div>
        ) : events.length === 0 ? (
          <div className="py-16 text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-[#EAF4EC] text-[#27864B] flex items-center justify-center mx-auto">
              <Sprout className="w-6 h-6" />
            </div>
            <div className="text-sm font-bold text-[#202B24]">Chưa có ghi chép canh tác nào</div>
            <p className="text-xs text-[#718078] max-w-sm mx-auto">
              Hãy nhấn nút "Thêm Sự Kiện Canh Tác" ở góc trên để ghi lại đợt bón phân hoặc cải tạo đất đầu tiên của bạn.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAFCFA] border-b border-[#E5EBE6] text-[#718078] font-semibold">
                <tr>
                  <th className="py-3 px-4">NGÀY THỰC HIỆN</th>
                  <th className="py-3 px-4">LOẠI CAN THIỆP</th>
                  <th className="py-3 px-4">LIỀU LƯỢNG</th>
                  <th className="py-3 px-4">TRẠM ĐO / LÔ ĐẤT</th>
                  <th className="py-3 px-4">GHI CHÚ / TÊN VẬT TƯ</th>
                  <th className="py-3 px-4 text-right">THAO TÁC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5EBE6] text-[#202B24]">
                {events.map((evt) => (
                  <tr key={evt.id} className="hover:bg-[#F9FBFA] transition-colors">
                    <td className="py-3.5 px-4 font-mono font-semibold text-[#202B24]">
                      {new Date(evt.eventDate).toLocaleDateString('vi-VN')}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${getBadgeStyle(evt.eventType)}`}>
                        <Sprout className="w-3 h-3" />
                        <span>{evt.eventType}</span>
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-[#202B24]">
                      {evt.amount} <span className="text-[11px] font-normal text-[#718078]">{evt.unit}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-[#202B24] flex items-center gap-1.5">
                        {evt.deviceType === 'fixed' ? (
                          <Radio className="w-3.5 h-3.5 text-[#2563EB]" />
                        ) : (
                          <Smartphone className="w-3.5 h-3.5 text-[#D97706]" />
                        )}
                        <span>{evt.deviceName}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-[#718078] max-w-xs truncate">
                      {evt.notes || '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => handleDeleteEvent(evt.id, evt.eventType, evt.eventDate)}
                        className="p-1.5 rounded-lg text-[#9CAAA2] hover:text-[#DC6262] hover:bg-[#FCECEC] transition-colors"
                        title="Xóa sự kiện nhập sai (UC-14 Alt 5a)"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL THÊM SỰ KIỆN CANH TÁC MỚI (UC-14 Step 6) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in-50">
          <div className="bg-white rounded-2xl border border-[#E5EBE6] shadow-modal max-w-lg w-full overflow-hidden">
            <div className="px-6 py-4 border-b border-[#E5EBE6] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#EAF4EC] text-[#27864B] flex items-center justify-center">
                  <Sprout className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#202B24]">Ghi Nhận Sự Kiện Canh Tác</h3>
                  <p className="text-[11px] text-[#718078]">Thông tin sẽ được đồng bộ cọc mốc lên biểu đồ dinh dưỡng</p>
                </div>
              </div>

              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-lg text-[#9CAAA2] hover:text-[#202B24] hover:bg-[#F2F5F3]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="p-6 space-y-4">
              {modalError && (
                <div className="p-3 bg-[#FCECEC] border border-[#F8D2D2] text-[#DC6262] rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{modalError}</span>
                </div>
              )}

              {/* Trạm đo áp dụng */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Trạm quan trắc / Lô đất áp dụng <span className="text-[#DC6262]">*</span>
                </label>
                <select
                  value={formDeviceId}
                  onChange={(e) => setFormDeviceId(e.target.value)}
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] focus:bg-white"
                  required
                >
                  {devices.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.type === 'fixed' ? 'Trạm Cố Định' : 'Cầm Tay Dã Ngoại'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Loại can thiệp */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Loại can thiệp nông học <span className="text-[#DC6262]">*</span>
                </label>
                <select
                  value={formEventType}
                  onChange={(e) => setFormEventType(e.target.value)}
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] focus:bg-white"
                >
                  <option value="Bón thúc">Bón thúc (Đón đòng / Ra hoa)</option>
                  <option value="Bón thúc nuôi quả">Bón thúc nuôi củ / Nuôi quả</option>
                  <option value="Bón lót">Bón lót (Đầu vụ / Cày ải)</option>
                  <option value="Bón vôi khử chua">Bón vôi khử chua / Nâng pH</option>
                  <option value="Rửa mặn / Xả phèn">Rửa mặn / Xả phèn</option>
                  <option value="Tưới ẩm giữ ẩm">Tưới ẩm / Điều tiết nước</option>
                  <option value="Phun phân bón lá">Phun phân bón lá / Vi lượng</option>
                </select>
              </div>

              {/* Liều lượng & Đơn vị tính */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                    Liều lượng <span className="text-[#DC6262]">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    value={formAmount}
                    onChange={(e) => setFormAmount(e.target.value)}
                    placeholder="VD: 25.0"
                    className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                    Đơn vị tính <span className="text-[#DC6262]">*</span>
                  </label>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] focus:bg-white"
                  >
                    <option value="kg/sào">kg / sào (Bắc Bộ / Trung Bộ)</option>
                    <option value="kg/ha">kg / ha</option>
                    <option value="tấn/ha">tấn / ha</option>
                    <option value="lít/ha">lít / ha (Phân nước)</option>
                    <option value="bao">bao</option>
                  </select>
                </div>
              </div>

              {/* Ngày thực hiện (Alt 6a: max = today) */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Ngày thực hiện canh tác <span className="text-[#DC6262]">*</span>
                </label>
                <input
                  type="date"
                  max={new Date().toISOString().slice(0, 10)}
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white"
                  required
                />
                <span className="text-[10px] text-[#718078] mt-1 block">
                  Chỉ cho phép chọn ngày hôm nay hoặc các ngày trong quá khứ.
                </span>
              </div>

              {/* Ghi chú / Tên phân bón */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Tên loại phân bón / Ghi chú kỹ thuật
                </label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="VD: Phân NPK 16-16-8 Đầu Trâu kết hợp tưới đẫm"
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white"
                />
              </div>

              {/* Nút hành động */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg border border-[#E5EBE6] text-xs font-semibold text-[#718078] hover:bg-[#F2F5F3]"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold transition-colors shadow-xs"
                >
                  {submitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Đang lưu...</span>
                    </>
                  ) : (
                    <span>Lưu Nhật Ký Canh Tác</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
