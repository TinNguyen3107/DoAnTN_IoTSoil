import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Activity, 
  Radio, 
  Smartphone, 
  RefreshCw, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Thermometer,
  Droplets,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';

export default function RealtimeMonitoring({ devices = [], onNavigateToDevices }) {
  const [selectedDeviceId, setSelectedDeviceId] = useState(devices[0]?.id ? String(devices[0].id) : '');
  const [reading, setReading] = useState(null);
  const [loading, setLoading] = useState(false);
  const [lastFetched, setLastFetched] = useState(new Date());

  const selectedDevice = devices.find(d => String(d.id) === String(selectedDeviceId)) || null;

  // Đồng bộ trạm mặc định khi danh sách thiết bị thay đổi
  useEffect(() => {
    if (devices.length > 0) {
      const exists = devices.some(d => String(d.id) === String(selectedDeviceId));
      if (!selectedDeviceId || !exists) {
        setSelectedDeviceId(String(devices[0].id));
      }
    } else {
      setSelectedDeviceId('');
      setReading(null);
    }
  }, [devices]);

  // Hàm tải bản ghi số đo mới nhất
  const fetchLatestReading = async (deviceId) => {
    if (!deviceId) return;
    try {
      setLoading(true);
      const res = await axios.get(`/api/readings/latest?deviceId=${deviceId}`);
      if (res.data?.success) {
        setReading(res.data.data);
        setLastFetched(new Date());
      }
    } catch (err) {
      console.error('Lỗi nạp số đo mới nhất:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedDeviceId) {
      fetchLatestReading(selectedDeviceId);
    }
  }, [selectedDeviceId]);

  // Vòng lặp tự động cập nhật số liệu mỗi 10 giây (UC-08: Real-time Polling)
  useEffect(() => {
    const timer = setInterval(() => {
      if (selectedDeviceId) {
        fetchLatestReading(selectedDeviceId);
      }
    }, 10000);

    return () => clearInterval(timer);
  }, [selectedDeviceId]);

  // Đánh giá nhanh trạng thái đất từ số đo thực tế (UC-09)
  const getSoilEvaluation = (r) => {
    if (!r) return null;
    const ph = Number(r.ph);
    const ec = Number(r.ec);
    const n = Number(r.n);

    let status = 'Đất Phì Nhiêu Chuẩn';
    let desc = 'Các chỉ số dinh dưỡng cân đối, môi trường rễ thông thoáng.';
    let level = 'optimal';

    if (ph < 5.5) {
      status = 'Đất Bị Chua / Phèn';
      desc = `Độ pH đạt ${ph} (< 5.5). Cần bón vôi nông nghiệp để nâng pH giúp rễ hấp thu lân tốt hơn.`;
      level = 'warning';
    } else if (ph > 7.5) {
      status = 'Đất Bị Kiềm Hóa';
      desc = `Độ pH đạt ${ph} (> 7.5). Cần bổ sung phân hữu cơ hoặc lưu huỳnh để hạ pH.`;
      level = 'warning';
    } else if (ec > 1200) {
      status = 'Đất Có Dấu Hiệu Mặn Hóa';
      desc = `Độ dẫn điện EC = ${ec} µS/cm. Nồng độ muối hòa tan cao, cần thau chua rửa mặn.`;
      level = 'danger';
    } else if (n < 50) {
      status = 'Đất Nghèo Dinh Dưỡng Đạm';
      desc = `Nồng độ Đạm N = ${n} mg/kg (< 50). Cây trồng có nguy cơ vàng lá, chậm phát triển.`;
      level = 'warning';
    }

    return { status, desc, level };
  };

  const evalResult = getSoilEvaluation(reading);

  return (
    <div className="space-y-6">
      {/* Page Title & Station Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Giám Sát Thổ Nhưỡng Thời Gian Thực
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Hiển thị trực tiếp 7 thông số cảm biến NPK kết nối với trạm đo được chọn (tự động cập nhật mỗi 10s).
          </p>
        </div>

        {/* Station Selector Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-[#718078]">Chọn trạm:</label>
          <select
            value={selectedDeviceId}
            onChange={(e) => setSelectedDeviceId(e.target.value)}
            disabled={devices.length === 0}
            className="bg-white border border-[#E5EBE6] rounded-lg px-3 py-1.5 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] shadow-xs disabled:opacity-60"
          >
            {devices.length === 0 ? (
              <option value="">Chưa có trạm đo nào</option>
            ) : (
              devices.map((d) => (
                <option key={d.id} value={d.id}>
                  #{String(d.id).padStart(3, '0')} — {d.name} ({d.type === 'fixed' ? 'Cố định' : 'Cầm tay'})
                </option>
              ))
            )}
          </select>
        </div>
      </div>

      {devices.length === 0 ? (
        <div className="bg-white border border-[#E5EBE6] rounded-card p-12 text-center shadow-subtle space-y-3">
          <Radio className="w-8 h-8 text-[#9CAAA2] mx-auto stroke-[1.5]" />
          <div className="text-sm font-semibold text-[#202B24]">
            Chưa có trạm quan trắc nào trong hệ thống
          </div>
          <p className="text-xs text-[#718078] max-w-md mx-auto">
            Hãy vào mục Quản lý trạm đo để thêm trạm thu thập mới và nhận mã API Key trước khi theo dõi số liệu thời gian thực.
          </p>
          {onNavigateToDevices && (
            <button
              onClick={onNavigateToDevices}
              className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-xs mt-1"
            >
              <span>Đi tới Quản Lý Trạm Đo</span>
            </button>
          )}
        </div>
      ) : (
        <>
          {/* Station Context Card */}
          <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#EAF4EC] text-[#27864B] flex items-center justify-center shrink-0">
                {selectedDevice?.type === 'fixed' ? <Radio className="w-5 h-5" /> : <Smartphone className="w-5 h-5" />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-[#202B24]">{selectedDevice?.name || 'Trạm Quan Trắc'}</span>
                  <span className={`text-[10px] font-medium px-2 py-0.5 rounded-md ${
                    selectedDevice?.type === 'fixed' 
                      ? 'bg-[#EBF3FA] text-[#2563EB] border border-[#CFE3F5]' 
                      : 'bg-[#FDF6E9] text-[#D97706] border border-[#F6DEB5]'
                  }`}>
                    {selectedDevice?.type === 'fixed' ? 'Trạm Cố Định NTP (Auto)' : 'Thiết Bị Cầm Tay (Manual)'}
                  </span>
                </div>
                <div className="text-xs text-[#718078] flex items-center gap-3 mt-1 font-mono">
                  <span>Mã ID: #{selectedDevice?.id}</span>
                  <span>•</span>
                  <span className={`flex items-center gap-1 ${selectedDevice?.is_active ? 'text-[#26965A]' : 'text-[#DC6262]'}`}>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{selectedDevice?.is_active ? 'Đang hoạt động' : 'Đang tạm khóa'}</span>
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono text-[#718078] bg-[#F7F9F7] px-3.5 py-2 rounded-lg border border-[#E5EBE6]">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#27864B]" />
                <span>Đồng bộ tự động: 10s</span>
              </div>
              <span>•</span>
              <button 
                onClick={() => fetchLatestReading(selectedDeviceId)}
                disabled={loading || !selectedDeviceId}
                className="text-[#27864B] hover:text-[#1F713E] flex items-center gap-1 font-sans font-semibold disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
                <span>Làm mới</span>
              </button>
            </div>
          </div>

          {!reading ? (
            <div className="bg-white border border-[#E5EBE6] rounded-card p-12 text-center shadow-subtle space-y-3">
              <Activity className="w-8 h-8 text-[#9CAAA2] mx-auto animate-pulse" />
              <div className="text-sm font-semibold text-[#202B24]">
                Chưa có bản ghi số đo nào cho trạm này
              </div>
              <p className="text-xs text-[#718078] max-w-md mx-auto">
                Trạm đo chưa nhận được bản ghi đầu tiên. Hãy gửi gói tin JSON kèm <code className="font-mono bg-[#F2F5F3] px-1 rounded">x-api-key</code> tới <code className="font-mono bg-[#F2F5F3] px-1 rounded">POST /api/readings/ingest</code> hoặc chạy giả lập để xem số liệu hiển thị tại đây.
              </p>
            </div>
          ) : (
        <>
          {/* 7 Telemetry Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Metric 1: N */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#0284C7]">Đạm tổng số (N)</span>
                <span className="font-mono text-[11px]">mg/kg</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.n}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 50 – 150</span>
                <span className={`font-semibold px-1.5 py-0.2 rounded ${
                  reading.n >= 50 && reading.n <= 150 
                    ? 'text-[#26965A] bg-[#EAF4EC]' 
                    : 'text-[#D97706] bg-[#FDF6E9]'
                }`}>
                  {reading.n >= 50 && reading.n <= 150 ? 'Đầy đủ' : reading.n < 50 ? 'Thiếu hụt' : 'Dư thừa'}
                </span>
              </div>
            </div>

            {/* Metric 2: P */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#EA580C]">Lân dễ tiêu (P)</span>
                <span className="font-mono text-[11px]">mg/kg</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.p}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 30 – 80</span>
                <span className={`font-semibold px-1.5 py-0.2 rounded ${
                  reading.p >= 30 && reading.p <= 80 
                    ? 'text-[#26965A] bg-[#EAF4EC]' 
                    : 'text-[#D97706] bg-[#FDF6E9]'
                }`}>
                  {reading.p >= 30 && reading.p <= 80 ? 'Đầy đủ' : reading.p < 30 ? 'Thiếu hụt' : 'Dư thừa'}
                </span>
              </div>
            </div>

            {/* Metric 3: K */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#7C3AED]">Kali trao đổi (K)</span>
                <span className="font-mono text-[11px]">mg/kg</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.k}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 80 – 200</span>
                <span className={`font-semibold px-1.5 py-0.2 rounded ${
                  reading.k >= 80 && reading.k <= 200 
                    ? 'text-[#26965A] bg-[#EAF4EC]' 
                    : 'text-[#D97706] bg-[#FDF6E9]'
                }`}>
                  {reading.k >= 80 && reading.k <= 200 ? 'Đầy đủ' : reading.k < 80 ? 'Thiếu hụt' : 'Dư thừa'}
                </span>
              </div>
            </div>

            {/* Metric 4: pH */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#2563EB]">Độ chua (pH)</span>
                <span className="font-mono text-[11px]">Scale</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.ph}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 5.5 – 7.0</span>
                <span className={`font-semibold px-1.5 py-0.2 rounded ${
                  reading.ph >= 5.5 && reading.ph <= 7.0 
                    ? 'text-[#26965A] bg-[#EAF4EC]' 
                    : 'text-[#DC6262] bg-[#FCECEC]'
                }`}>
                  {reading.ph < 5.5 ? 'Đất chua / phèn' : reading.ph > 7.0 ? 'Đất kiềm' : 'Trung tính'}
                </span>
              </div>
            </div>

            {/* Metric 5: EC */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#D97706]">Độ dẫn điện (EC)</span>
                <span className="font-mono text-[11px]">µS/cm</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.ec}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 300 – 1200</span>
                <span className={`font-semibold px-1.5 py-0.2 rounded ${
                  reading.ec <= 1200 
                    ? 'text-[#26965A] bg-[#EAF4EC]' 
                    : 'text-[#DC6262] bg-[#FCECEC]'
                }`}>
                  {reading.ec <= 1200 ? 'Bình thường' : 'Nguy cơ mặn'}
                </span>
              </div>
            </div>

            {/* Metric 6: Nhiệt độ */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#E11D48]">Nhiệt độ tầng rễ</span>
                <span className="font-mono text-[11px]">°C</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.temperature}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 18 – 35</span>
                <span className="text-[#26965A] font-semibold bg-[#EAF4EC] px-1.5 py-0.2 rounded">Ổn định</span>
              </div>
            </div>

            {/* Metric 7: Độ ẩm */}
            <div className="bg-white border border-[#E5EBE6] rounded-card p-4 shadow-subtle space-y-2">
              <div className="flex items-center justify-between text-xs text-[#718078]">
                <span className="font-semibold text-[#0D9488]">Độ ẩm đất</span>
                <span className="font-mono text-[11px]">%</span>
              </div>
              <div className="text-2xl font-bold text-[#202B24] mono-tabular">
                {reading.moisture}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#F2F5F3]">
                <span className="text-[#718078]">Ngưỡng: 50 – 80</span>
                <span className="text-[#26965A] font-semibold bg-[#EAF4EC] px-1.5 py-0.2 rounded">Tốt</span>
              </div>
            </div>

            {/* Metadata Summary Card */}
            <div className="bg-[#FAFCFA] border border-[#CDE5D4] rounded-card p-4 shadow-subtle flex flex-col justify-between">
              <div>
                <div className="text-xs font-semibold text-[#27864B] uppercase tracking-wide">
                  Thông Tin Gói Tin IoT
                </div>
                <div className="text-sm font-bold text-[#202B24] mt-1 font-mono">
                  Bản ghi #{reading.id}
                </div>
                <div className="text-[11px] text-[#718078] mt-1">
                  Chế độ: <strong className="text-[#202B24] uppercase">{reading.mode === 'auto' ? 'Tự động (NTP)' : 'Thủ công (Nút bấm)'}</strong>
                </div>
              </div>
              <div className="text-[10px] font-mono text-[#718078] pt-2 border-t border-[#CDE5D4]">
                Đo lúc: {new Date(reading.measured_at).toLocaleString('vi-VN')}
              </div>
            </div>
          </div>

          {/* UC-09: Soil Health Evaluation Banner */}
          {evalResult && (
            <div className={`p-4 rounded-xl border flex items-start gap-3 shadow-subtle ${
              evalResult.level === 'optimal' 
                ? 'bg-[#EAF4EC] border-[#CDE5D4] text-[#202B24]' 
                : evalResult.level === 'warning' 
                ? 'bg-[#FFFBEB] border-[#FEE685] text-[#8C5810]' 
                : 'bg-[#FCECEC] border-[#F8D2D2] text-[#8C1D1D]'
            }`}>
              <div className="p-2 rounded-lg bg-white/80 shrink-0">
                {evalResult.level === 'optimal' ? (
                  <CheckCircle2 className="w-5 h-5 text-[#26965A]" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-[#D97706]" />
                )}
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wide">
                  {evalResult.status}
                </div>
                <p className="text-xs mt-0.5 leading-relaxed">
                  {evalResult.desc}
                </p>
              </div>
            </div>
          )}
        </>
      )}
        </>
      )}
    </div>
  );
}
