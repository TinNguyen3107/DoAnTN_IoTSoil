import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Sparkles, 
  Calculator, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Sprout,
  Radio,
  Smartphone,
  ChevronDown,
  RefreshCw,
  Scale,
  Calendar,
  Layers,
  Info,
  ShieldAlert,
  Flame,
  Award
} from 'lucide-react';

export default function Recommendations({ devices = [] }) {
  const [activeSubTab, setActiveSubTab] = useState('fertilizer'); // 'fertilizer' | 'crops'

  // Trạng thái trạm đo được chọn
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [crops, setCrops] = useState([]);

  // Form Tính Phân Bón (UC-15)
  const [selectedCropId, setSelectedCropId] = useState('');
  const [areaValue, setAreaValue] = useState('1');
  const [areaUnit, setAreaUnit] = useState('ha');
  const [fertilizerAdvice, setFertilizerAdvice] = useState(null);
  const [loadingFertilizer, setLoadingFertilizer] = useState(false);
  const [fertilizerError, setFertilizerError] = useState('');

  // Gợi Ý Cây Trồng (UC-16)
  const [suitableCropsResult, setSuitableCropsResult] = useState(null);
  const [loadingCrops, setLoadingCrops] = useState(false);
  const [cropsError, setCropsError] = useState('');

  // Tải danh mục cây trồng
  useEffect(() => {
    const fetchCrops = async () => {
      try {
        const res = await axios.get('/api/recommendations/crops');
        if (res.data?.success && res.data.data.length > 0) {
          setCrops(res.data.data);
          setSelectedCropId(String(res.data.data[0].id));
        }
      } catch (err) {
        console.error('Lỗi tải danh mục cây trồng:', err);
      }
    };
    fetchCrops();
  }, []);

  // Khởi tạo / đồng bộ trạm mặc định khi danh sách thiết bị thay đổi
  useEffect(() => {
    if (devices.length > 0) {
      const exists = devices.some(d => String(d.id) === String(selectedDeviceId));
      if (!selectedDeviceId || !exists) {
        setSelectedDeviceId(String(devices[0].id));
      }
    } else {
      setSelectedDeviceId('');
      setFertilizerAdvice(null);
      setSuitableCropsResult(null);
    }
  }, [devices]);

  // UC-15: Tính toán lượng phân bón NPK
  const handleCalculateFertilizer = async () => {
    if (!selectedDeviceId || !selectedCropId) return;

    try {
      setLoadingFertilizer(true);
      setFertilizerError('');
      const res = await axios.get(
        `/api/recommendations/fertilizer?deviceId=${selectedDeviceId}&cropId=${selectedCropId}&area=${areaValue}&unit=${areaUnit}`
      );
      if (res.data?.success) {
        setFertilizerAdvice(res.data.data);
      }
    } catch (err) {
      setFertilizerError(err.response?.data?.message || 'Không thể tính toán lượng phân bón.');
      setFertilizerAdvice(null);
    } finally {
      setLoadingFertilizer(false);
    }
  };

  // UC-16: Đánh giá thích nghi và gợi ý Top 3 giống cây
  const handleFindSuitableCrops = async () => {
    if (!selectedDeviceId) return;

    try {
      setLoadingCrops(true);
      setCropsError('');
      const res = await axios.get(`/api/recommendations/suitable-crops?deviceId=${selectedDeviceId}`);
      if (res.data?.success) {
        setSuitableCropsResult(res.data.data);
      }
    } catch (err) {
      setCropsError(err.response?.data?.message || 'Không thể đánh giá độ thích nghi cây trồng.');
      setSuitableCropsResult(null);
    } finally {
      setLoadingCrops(false);
    }
  };

  // Tự động tính toán khi chọn trạm hoặc đổi cây
  useEffect(() => {
    if (selectedDeviceId && selectedCropId) {
      handleCalculateFertilizer();
    }
  }, [selectedDeviceId, selectedCropId, areaUnit]);

  useEffect(() => {
    if (selectedDeviceId && activeSubTab === 'crops') {
      handleFindSuitableCrops();
    }
  }, [selectedDeviceId, activeSubTab]);

  return (
    <div className="space-y-6">
      {/* Tiêu đề trang & Tabs chuyển đổi nghiệp vụ */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Tư Vấn Nông Nghiệp & Tối Ưu Dinh Dưỡng
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Động cơ khuyến nông tự động: Tính toán định mức phân bón thương phẩm NPK cân đối và xếp hạng giống cây trồng thích ứng đất.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="inline-flex p-1 rounded-xl bg-white border border-[#E5EBE6] shadow-subtle text-xs">
          <button
            onClick={() => setActiveSubTab('fertilizer')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-medium transition-all ${
              activeSubTab === 'fertilizer'
                ? 'bg-[#EAF4EC] text-[#27864B] font-semibold shadow-xs'
                : 'text-[#718078] hover:text-[#202B24]'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Tư Vấn Liều Lượng NPK</span>
          </button>

          <button
            onClick={() => setActiveSubTab('crops')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-medium transition-all ${
              activeSubTab === 'crops'
                ? 'bg-[#EAF4EC] text-[#27864B] font-semibold shadow-xs'
                : 'text-[#718078] hover:text-[#202B24]'
            }`}
          >
            <Sprout className="w-3.5 h-3.5" />
            <span>Gợi Ý Cây Trồng Phù Hợp</span>
          </button>
        </div>
      </div>

      {/* Thanh chọn trạm quan trắc chung */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-3 shadow-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <label className="text-xs font-semibold text-[#718078] shrink-0">Trạm quan trắc thực địa:</label>
          <div className="relative min-w-[260px] w-full sm:w-auto">
            <select
              value={selectedDeviceId}
              onChange={(e) => setSelectedDeviceId(e.target.value)}
              disabled={devices.length === 0}
              className="w-full appearance-none bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-1.5 pr-8 text-xs font-semibold text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors cursor-pointer disabled:opacity-60"
            >
              {devices.length === 0 ? (
                <option value="">Chưa có trạm đo nào</option>
              ) : (
                devices.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.type === 'fixed' ? 'Cố định' : 'Cầm tay'})
                  </option>
                ))
              )}
            </select>
            <ChevronDown className="w-4 h-4 text-[#9CAAA2] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        <div className="text-[11px] text-[#718078] hidden sm:flex items-center gap-1.5 font-mono">
          <span className="w-2 h-2 rounded-full bg-[#27864B]"></span>
          <span>Dựa trên số đo cảm biến mới nhất</span>
        </div>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: TƯ VẤN ĐỊNH LƯỢNG PHÂN BÓN NPK (UC-15) */}
      {/* ======================================================== */}
      {activeSubTab === 'fertilizer' && (
        <div className="space-y-6 animate-in fade-in-50">
          {/* Hộp Thiết Lập Thông Số Canh Tác */}
          <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
            <div className="flex items-center justify-between border-b border-[#E5EBE6] pb-3">
              <div>
                <h2 className="text-sm font-bold text-[#202B24] flex items-center gap-2">
                  <Scale className="w-4 h-4 text-[#27864B]" />
                  <span>Thiết Lập Mục Tiêu & Diện Tích Canh Tác</span>
                </h2>
                <p className="text-[11px] text-[#718078] mt-0.5">
                  Hệ thống đối chiếu định mức nhu cầu của cây với số đo đất để tính lượng thiếu hụt và quy đổi ra phân thương phẩm.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {/* Chọn Giống Cây Trồng */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Giống cây trồng mục tiêu:
                </label>
                <div className="relative">
                  <select
                    value={selectedCropId}
                    onChange={(e) => setSelectedCropId(e.target.value)}
                    className="w-full appearance-none bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 pr-8 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors cursor-pointer"
                  >
                    {crops.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-[#9CAAA2] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              {/* Diện Tích Canh Tác */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Quy mô diện tích:
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={areaValue}
                  onChange={(e) => setAreaValue(e.target.value)}
                  className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 text-xs font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white"
                  placeholder="VD: 1.0"
                />
              </div>

              {/* Đơn Vị Diện Tích */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Đơn vị đo lường:
                </label>
                <div className="relative">
                  <select
                    value={areaUnit}
                    onChange={(e) => setAreaUnit(e.target.value)}
                    className="w-full appearance-none bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 pr-8 text-xs text-[#202B24] font-medium focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors cursor-pointer"
                  >
                    <option value="ha">Hecta (10.000 m²)</option>
                    <option value="sao_bac_bo">Sào Bắc Bộ (360 m²)</option>
                    <option value="sao_trung_bo">Sào Trung Bộ (500 m²)</option>
                    <option value="m2">Mét vuông (m²)</option>
                  </select>
                  <ChevronDown className="w-4 h-4 text-[#9CAAA2] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={handleCalculateFertilizer}
                disabled={loadingFertilizer || !selectedDeviceId || !selectedCropId}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#27864B] hover:bg-[#1F713E] disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-semibold transition-colors shadow-xs"
              >
                {loadingFertilizer ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Đang tính toán...</span>
                  </>
                ) : (
                  <>
                    <Calculator className="w-3.5 h-3.5" />
                    <span>Tính Lượng Phân Bón</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {fertilizerError && (
            <div className="p-4 bg-[#FCECEC] border border-[#F8D2D2] text-[#DC6262] rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{fertilizerError}</span>
            </div>
          )}

          {/* Kết quả tư vấn */}
          {fertilizerAdvice && (
            <div className="space-y-6">
              {/* Thông báo khuyến nghị & Chẩn đoán */}
              <div className={`p-4 rounded-xl border text-xs leading-relaxed flex items-start gap-3 shadow-subtle ${
                fertilizerAdvice.isTotallySurplus
                  ? 'bg-[#FFF8E6] border-[#FDE68A] text-[#B45309]'
                  : 'bg-[#EAF4EC] border-[#CDE5D4] text-[#202B24]'
              }`}>
                {fertilizerAdvice.isTotallySurplus ? (
                  <ShieldAlert className="w-5 h-5 text-[#D97706] shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-[#27864B] shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="font-bold text-sm">
                    {fertilizerAdvice.isTotallySurplus ? 'Cảnh Báo: Đất Giàu Dinh Dưỡng' : 'Kết Quả Tư Vấn Phân Bón Cân Đối'}
                  </div>
                  <div>{fertilizerAdvice.adviceMessage}</div>
                </div>
              </div>

              {/* 3 Thẻ Phân Bón Thương Phẩm Cần Bổ Sung */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. Phân Urê */}
                <div className="bg-white border border-[#E5EBE6] rounded-card p-4.5 shadow-subtle space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0284C7] uppercase tracking-wide">
                      Phân Urê (Đạm 46% N)
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#E0F2FE] text-[#0284C7] font-semibold">
                      Bổ sung Đạm
                    </span>
                  </div>

                  <div className="text-2xl font-bold font-mono text-[#202B24]">
                    {fertilizerAdvice.fertilizers.urea}{' '}
                    <span className="text-xs font-normal text-[#718078]">kg</span>
                  </div>

                  <div className="text-[11px] text-[#718078] pt-1 border-t border-[#E5EBE6]">
                    Hiện trạng: <strong>{fertilizerAdvice.currentValues.n}</strong> mg/kg • Nhu cầu: <strong>{fertilizerAdvice.targetValues.n}</strong> mg/kg
                  </div>
                </div>

                {/* 2. Super Lân */}
                <div className="bg-white border border-[#E5EBE6] rounded-card p-4.5 shadow-subtle space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#EA580C] uppercase tracking-wide">
                      Super Lân (16% P₂O₅)
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#FFEDD5] text-[#EA580C] font-semibold">
                      Bổ sung Lân
                    </span>
                  </div>

                  <div className="text-2xl font-bold font-mono text-[#202B24]">
                    {fertilizerAdvice.fertilizers.superPhosphate}{' '}
                    <span className="text-xs font-normal text-[#718078]">kg</span>
                  </div>

                  <div className="text-[11px] text-[#718078] pt-1 border-t border-[#E5EBE6]">
                    Hiện trạng: <strong>{fertilizerAdvice.currentValues.p}</strong> mg/kg • Nhu cầu: <strong>{fertilizerAdvice.targetValues.p2o5}</strong> mg/kg
                  </div>
                </div>

                {/* 3. Kali Clorua */}
                <div className="bg-white border border-[#E5EBE6] rounded-card p-4.5 shadow-subtle space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#7C3AED] uppercase tracking-wide">
                      Kali Clorua (60% K₂O)
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#EDE9FE] text-[#7C3AED] font-semibold">
                      Bổ sung Kali
                    </span>
                  </div>

                  <div className="text-2xl font-bold font-mono text-[#202B24]">
                    {fertilizerAdvice.fertilizers.potassiumChloride}{' '}
                    <span className="text-xs font-normal text-[#718078]">kg</span>
                  </div>

                  <div className="text-[11px] text-[#718078] pt-1 border-t border-[#E5EBE6]">
                    Hiện trạng: <strong>{fertilizerAdvice.currentValues.k}</strong> mg/kg • Nhu cầu: <strong>{fertilizerAdvice.targetValues.k2o}</strong> mg/kg
                  </div>
                </div>
              </div>

              {/* Lịch Phân Chia Các Đợt Bón Phân */}
              {!fertilizerAdvice.isTotallySurplus && (
                <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-3">
                  <div className="flex items-center justify-between border-b border-[#E5EBE6] pb-3">
                    <h3 className="text-sm font-bold text-[#202B24] flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#27864B]" />
                      <span>Hướng Dẫn Phân Chia Các Đợt Bón Thực Địa</span>
                    </h3>
                    <span className="text-[11px] text-[#718078]">Quy chuẩn nông học chuyên canh</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#FAFCFA] border-b border-[#E5EBE6] text-[#718078] font-semibold">
                        <tr>
                          <th className="py-2.5 px-3">GIAI ĐOẠN PHÁT TRIỂN</th>
                          <th className="py-2.5 px-3">THỜI ĐIỂM ÁP DỤNG</th>
                          <th className="py-2.5 px-3 text-right">URÊ (46% N)</th>
                          <th className="py-2.5 px-3 text-right">SUPER LÂN (16%)</th>
                          <th className="py-2.5 px-3 text-right">KALI CLORUA (60%)</th>
                          <th className="py-2.5 px-3">MỤC TIÊU NÔNG HỌC</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#E5EBE6] text-[#202B24]">
                        {fertilizerAdvice.schedule.map((s, idx) => (
                          <tr key={idx} className="hover:bg-[#F9FBFA] transition-colors">
                            <td className="py-3 px-3 font-semibold text-[#202B24]">
                              {s.stage}
                            </td>
                            <td className="py-3 px-3 text-[#718078]">
                              {s.timing}
                            </td>
                            <td className="py-3 px-3 text-right font-mono font-bold text-[#0284C7]">
                              {s.urea} kg
                            </td>
                            <td className="py-3 px-3 text-right font-mono font-bold text-[#EA580C]">
                              {s.superPhosphate} kg
                            </td>
                            <td className="py-3 px-3 text-right font-mono font-bold text-[#7C3AED]">
                              {s.potassiumChloride} kg
                            </td>
                            <td className="py-3 px-3 text-[#718078] text-[11px] max-w-xs">
                              {s.notes}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: GỢI Ý GIỐNG CÂY TRỒNG THÍCH HỢP (UC-16) */}
      {/* ======================================================== */}
      {activeSubTab === 'crops' && (
        <div className="space-y-6 animate-in fade-in-50">
          <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#E5EBE6] pb-3 gap-2">
              <div>
                <h2 className="text-sm font-bold text-[#202B24] flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#27864B]" />
                  <span>Xếp Hạng Giống Cây Thích Nghi Theo Thuật Toán Heuristic Đa Tiêu Chí</span>
                </h2>
                <p className="text-[11px] text-[#718078] mt-0.5">
                  Hệ thống tự động chấm điểm tương thích kết hợp giữa độ chua pH, khả năng chịu mặn EC và dinh dưỡng NPK để gợi ý Top 3 cây trồng tối ưu.
                </p>
              </div>

              <button
                onClick={handleFindSuitableCrops}
                disabled={loadingCrops}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold transition-colors shadow-xs"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingCrops ? 'animate-spin' : ''}`} />
                <span>Đánh Giá Lại</span>
              </button>
            </div>

            {loadingCrops ? (
              <div className="py-16 text-center text-xs text-[#718078]">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
                Đang chạy thuật toán chấm điểm tương thích sinh thái...
              </div>
            ) : cropsError ? (
              <div className="p-4 bg-[#FCECEC] border border-[#F8D2D2] text-[#DC6262] rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{cropsError}</span>
              </div>
            ) : suitableCropsResult?.needsSoilAmendment ? (
              // UC-16 Alt 4a: Không cây nào đạt điểm 50 -> Cảnh báo cải tạo đất
              <div className="p-5 bg-[#FFF8E6] border border-[#FDE68A] rounded-2xl text-xs text-[#B45309] space-y-3">
                <div className="flex items-center gap-2.5">
                  <ShieldAlert className="w-5 h-5 text-[#D97706] shrink-0" />
                  <span className="font-bold text-sm">
                    Khuyến Cáo Cải Tạo Thổ Nhưỡng Trước Khi Gieo Trồng
                  </span>
                </div>
                <p className="text-xs leading-relaxed text-[#202B24]">
                  {suitableCropsResult.amendmentAdvice}
                </p>
                <div className="p-3 bg-white/70 rounded-xl border border-[#FDE68A] text-[11px] text-[#718078] font-mono">
                  Số đo đất thực tế: pH = {suitableCropsResult.currentSoil.ph} • EC = {suitableCropsResult.currentSoil.ec} µS/cm • N = {suitableCropsResult.currentSoil.n} mg/kg
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Chỉ số đất hiện tại */}
                {suitableCropsResult?.currentSoil && (
                  <div className="p-3 bg-[#F7F9F7] border border-[#E5EBE6] rounded-xl flex flex-wrap items-center justify-between text-xs font-mono text-[#718078]">
                    <span>Hiện trạng trạm:</span>
                    <span className="font-bold text-[#202B24]">pH {suitableCropsResult.currentSoil.ph}</span>
                    <span>•</span>
                    <span className="font-bold text-[#202B24]">EC {suitableCropsResult.currentSoil.ec} µS/cm</span>
                    <span>•</span>
                    <span className="font-bold text-[#202B24]">N {suitableCropsResult.currentSoil.n} mg/kg</span>
                    <span>•</span>
                    <span className="font-bold text-[#202B24]">P {suitableCropsResult.currentSoil.p} mg/kg</span>
                    <span>•</span>
                    <span className="font-bold text-[#202B24]">K {suitableCropsResult.currentSoil.k} mg/kg</span>
                  </div>
                )}

                {/* Danh sách Top 3 cây trồng */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {suitableCropsResult?.topCrops.map((crop, idx) => (
                    <div
                      key={crop.id}
                      className="bg-white border border-[#E5EBE6] rounded-card p-4.5 shadow-subtle flex flex-col justify-between space-y-4 hover:border-[#27864B] transition-colors"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#EAF4EC] text-[#27864B]">
                              Top {idx + 1} Thích Ứng
                            </span>
                            <h3 className="font-bold text-sm text-[#202B24] mt-1.5">
                              {crop.name}
                            </h3>
                          </div>
                          <div className="text-right">
                            <div className="text-xl font-bold font-mono text-[#27864B]">
                              {crop.score}
                              <span className="text-xs font-normal text-[#718078]">/100</span>
                            </div>
                            <span className="text-[10px] text-[#718078]">Điểm thích nghi</span>
                          </div>
                        </div>

                        {/* Điểm thuận lợi */}
                        <div className="space-y-1.5 text-xs">
                          <div className="text-[11px] font-semibold text-[#27864B] flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Ưu điểm thổ nhưỡng:</span>
                          </div>
                          <ul className="space-y-1 text-[11px] text-[#718078] pl-4 list-disc">
                            {crop.pros.map((p, pIdx) => (
                              <li key={pIdx}>{p}</li>
                            ))}
                          </ul>
                        </div>

                        {/* Lưu ý nông học */}
                        {crop.cons.length > 0 && (
                          <div className="space-y-1.5 text-xs pt-1 border-t border-[#E5EBE6]">
                            <div className="text-[11px] font-semibold text-[#D97706] flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5" />
                              <span>Lưu ý canh tác:</span>
                            </div>
                            <ul className="space-y-1 text-[11px] text-[#718078] pl-4 list-disc">
                              {crop.cons.map((c, cIdx) => (
                                <li key={cIdx}>{c}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>

                      {/* Nút Chọn Cây Này Để Tính Phân Bón */}
                      <button
                        onClick={() => {
                          setSelectedCropId(String(crop.id));
                          setActiveSubTab('fertilizer');
                        }}
                        className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-[#CDE5D4] bg-[#EAF4EC] hover:bg-[#DDF0E1] text-xs font-semibold text-[#27864B] transition-colors shadow-xs"
                      >
                        <span>Tính Phân Bón Cho Cây Này</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
