import React from 'react';
import BrandLogo from './BrandLogo.jsx';
import { 
  LayoutDashboard, 
  Activity, 
  Radio, 
  SlidersHorizontal, 
  LineChart, 
  ClipboardList, 
  Sparkles, 
  Users, 
  Settings,
  ShieldCheck,
  UserCheck,
  LogOut,
  Bell
} from 'lucide-react';

export default function Sidebar({ activeTab, onSelectTab, counts = {}, currentUser, onLogout }) {
  const isAdmin = currentUser?.role === 'admin';

  // Nhóm menu phân quyền: Nông dân chỉ thấy các mục canh tác thực địa, Admin thấy toàn quyền
  const navSections = isAdmin ? [
    {
      title: 'TỔNG QUAN',
      items: [
        { id: 'dashboard', label: 'Tổng quan hệ thống', icon: LayoutDashboard },
        { id: 'telemetry', label: 'Giám sát thời gian thực', icon: Activity, badge: 'Live' },
      ]
    },
    {
      title: 'QUẢN LÝ THIẾT BỊ',
      items: [
        { id: 'devices', label: 'Trạm quan trắc & Khóa', icon: Radio, count: counts.devices },
        { id: 'thresholds', label: 'Cấu hình ngưỡng đất', icon: SlidersHorizontal },
        { id: 'alerts', label: 'Cảnh báo vượt ngưỡng', icon: Bell, count: counts.alerts },
      ]
    },
    {
      title: 'DỮ LIỆU & NHẬT KÝ',
      items: [
        { id: 'analytics', label: 'Biểu đồ lịch sử & CSV', icon: LineChart },
        { id: 'field_logs', label: 'Nhật ký đồng ruộng', icon: ClipboardList },
      ]
    },
    {
      title: 'TỐI ƯU DINH DƯỠNG',
      items: [
        { id: 'recommendations', label: 'Tư vấn NPK & Cây trồng', icon: Sparkles },
      ]
    },
    {
      title: 'HỆ THỐNG',
      items: [
        { id: 'users', label: 'Quản trị người dùng', icon: Users },
        { id: 'settings', label: 'Cài đặt hệ thống', icon: Settings },
      ]
    }
  ] : [
    // Menu tinh gọn dành riêng cho Nông dân (Farmer Portal)
    {
      title: 'CANH TÁC & GIÁM SÁT',
      items: [
        { id: 'telemetry', label: 'Giám sát chất lượng đất', icon: Activity, badge: 'Live' },
        { id: 'alerts', label: 'Cảnh báo vượt ngưỡng', icon: Bell, count: counts.alerts },
        { id: 'devices', label: 'Trạm đo của tôi', icon: Radio, count: counts.devices },
        { id: 'analytics', label: 'Lịch sử & Xuất báo cáo', icon: LineChart },
      ]
    },
    {
      title: 'HỖ TRỢ NÔNG NGHIỆP',
      items: [
        { id: 'field_logs', label: 'Sổ nhật ký bón phân', icon: ClipboardList },
        { id: 'recommendations', label: 'Tư vấn NPK & Cây trồng', icon: Sparkles },
      ]
    }
  ];

  return (
    <aside className="w-64 bg-white border-r border-[#E5EBE6] flex flex-col h-screen sticky top-0 shrink-0 select-none">
      {/* Brand Header */}
      <div className="h-16 px-5 flex items-center border-b border-[#E5EBE6]">
        <BrandLogo size={32} />
      </div>

      {/* Navigation Sections */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {navSections.map((section, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-3 text-[10px] font-bold tracking-wider text-[#9CAAA2] uppercase">
              {section.title}
            </div>

            <div className="space-y-0.5 pt-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-[13px] font-medium transition-all ${
                      isActive
                        ? 'bg-[#EAF4EC] text-[#27864B] font-semibold shadow-xs'
                        : 'text-[#718078] hover:bg-[#F2F5F3] hover:text-[#202B24]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon 
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          isActive ? 'text-[#27864B]' : 'text-[#718078]'
                        }`} 
                        strokeWidth={isActive ? 2.2 : 1.8}
                      />
                      <span>{item.label}</span>
                    </div>

                    {item.badge && (
                      <span className="text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded-full bg-[#EAF4EC] text-[#27864B] border border-[#CDE5D4]">
                        {item.badge}
                      </span>
                    )}

                    {item.count !== undefined && item.count > 0 && (
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#F2F5F3] text-[#718078]">
                        {item.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* User Information & Logout Footer */}
      <div className="p-3 border-t border-[#E5EBE6] bg-[#FCFDFD]">
        <div className="p-2.5 rounded-xl border border-[#E5EBE6] bg-white flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 border ${
              isAdmin 
                ? 'bg-[#EAF4EC] text-[#27864B] border-[#CDE5D4]' 
                : 'bg-[#FDF6E9] text-[#D97706] border-[#F6DEB5]'
            }`}>
              {currentUser?.fullName?.charAt(0) || (isAdmin ? 'A' : 'N')}
            </div>
            <div className="min-w-0 leading-tight">
              <div className="text-xs font-semibold text-[#202B24] truncate flex items-center gap-1.5">
                <span>{currentUser?.fullName || 'Người dùng'}</span>
                {isAdmin ? (
                  <ShieldCheck className="w-3.5 h-3.5 text-[#27864B] shrink-0" title="Quản trị viên" />
                ) : (
                  <UserCheck className="w-3.5 h-3.5 text-[#D97706] shrink-0" title="Nông dân" />
                )}
              </div>
              <div className="text-[11px] text-[#718078] truncate mt-0.5">
                {isAdmin ? 'Quản trị viên' : 'Chủ hộ nông dân'}
              </div>
            </div>
          </div>

          <button
            onClick={onLogout}
            title="Đăng xuất khỏi hệ thống"
            className="p-1.5 rounded-lg text-[#9CAAA2] hover:text-[#DC6262] hover:bg-[#FCECEC] transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
