import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Settings, 
  Database, 
  Shield, 
  Save, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  Sliders
} from 'lucide-react';

export default function SystemSettings() {
  const [configs, setConfigs] = useState({
    UREA_N_PERCENT: '46',
    SUPER_PHOSPHATE_P_PERCENT: '16',
    POTASSIUM_CHLORIDE_K_PERCENT: '60',
    SOIL_DEPTH_M: '0.2',
    SOIL_BULK_DENSITY: '1.3',
    AREA_M2_PER_HA: '10000'
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState({ type: '', text: '' });

  // Nạp tham số cấu hình từ máy chủ
  const fetchConfigs = async () => {
    try {
      setLoading(true);
      const res = await axios.get('/api/system-configs');
      if (res.data?.success && res.data.data?.map) {
        const m = res.data.data.map;
        setConfigs({
          UREA_N_PERCENT: String(m.UREA_N_PERCENT ?? 46),
          SUPER_PHOSPHATE_P_PERCENT: String(m.SUPER_PHOSPHATE_P_PERCENT ?? 16),
          POTASSIUM_CHLORIDE_K_PERCENT: String(m.POTASSIUM_CHLORIDE_K_PERCENT ?? 60),
          SOIL_DEPTH_M: String(m.SOIL_DEPTH_M ?? 0.2),
          SOIL_BULK_DENSITY: String(m.SOIL_BULK_DENSITY ?? 1.3),
          AREA_M2_PER_HA: String(m.AREA_M2_PER_HA ?? 10000)
        });
      }
    } catch (err) {
      console.error('Lỗi tải cấu hình hệ thống:', err);
      setStatusMessage({ type: 'error', text: 'Không thể tải cấu hình tham số từ máy chủ.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfigs();
  }, []);

  const handleChange = (key, value) => {
    setConfigs(prev => ({ ...prev, [key]: value }));
    if (statusMessage.text) setStatusMessage({ type: '', text: '' });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      setStatusMessage({ type: '', text: '' });

      const res = await axios.put('/api/system-configs', configs);
      if (res.data?.success) {
        setStatusMessage({ 
          type: 'success', 
          text: res.data.message || 'Đã lưu tham số nông học vào cơ sở dữ liệu thành công!' 
        });
      }
    } catch (err) {
      setStatusMessage({ 
        type: 'error', 
        text: err.response?.data?.message || 'Lỗi kiểm tra tham số đầu vào.' 
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Cài Đặt Hệ Thống & Tham Số Tính Toán
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Thiết lập các hằng số quy đổi nông học phục vụ tính toán liều lượng phân bón và theo dõi hạ tầng dịch vụ máy chủ.
          </p>
        </div>

        <button
          type="submit"
          disabled={saving || loading}
          className="inline-flex items-center gap-1.5 bg-[#27864B] hover:bg-[#1F713E] disabled:opacity-60 text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition-colors shadow-xs"
        >
          {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>{saving ? 'Đang lưu...' : 'Lưu Tham Số Hệ Thống'}</span>
        </button>
      </div>

      {/* Thông báo trạng thái lưu */}
      {statusMessage.text && (
        <div className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
          statusMessage.type === 'success'
            ? 'bg-[#EAF4EC] border-[#CDE5D4] text-[#27864B]'
            : 'bg-[#FCECEC] border-[#F8D2D2] text-[#DC6262]'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0" />
          )}
          <span className="font-medium">{statusMessage.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* NPK Fertilizer Engine Constants */}
        <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
          <div className="border-b border-[#E5EBE6] pb-3 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#27864B]" />
            <div>
              <h2 className="text-sm font-bold text-[#202B24]">
                Hệ Số Nồng Độ Phân Bón Thương Mại
              </h2>
              <p className="text-[11px] text-[#718078] mt-0.5">
                Hàm lượng dinh dưỡng quy đổi chuẩn phục vụ công thức khuyến nghị phân bón.
              </p>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-[#718078] mb-1">
                Tỷ lệ Đạm nguyên chất trong phân Urê (%):
              </label>
              <input
                type="number"
                step="0.1"
                min="1"
                max="100"
                value={configs.UREA_N_PERCENT}
                onChange={(e) => handleChange('UREA_N_PERCENT', e.target.value)}
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-[#718078] mb-1">
                Tỷ lệ P₂O₅ trong Supe Lân (%):
              </label>
              <input
                type="number"
                step="0.1"
                min="1"
                max="100"
                value={configs.SUPER_PHOSPHATE_P_PERCENT}
                onChange={(e) => handleChange('SUPER_PHOSPHATE_P_PERCENT', e.target.value)}
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-[#718078] mb-1">
                Tỷ lệ K₂O trong phân Kali Clorua (%):
              </label>
              <input
                type="number"
                step="0.1"
                min="1"
                max="100"
                value={configs.POTASSIUM_CHLORIDE_K_PERCENT}
                onChange={(e) => handleChange('POTASSIUM_CHLORIDE_K_PERCENT', e.target.value)}
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                required
              />
            </div>
          </div>
        </div>

        {/* Soil Volume & Area Constants */}
        <div className="bg-white border border-[#E5EBE6] rounded-card p-5 shadow-subtle space-y-4">
          <div className="border-b border-[#E5EBE6] pb-3 flex items-center gap-2">
            <Database className="w-4 h-4 text-[#27864B]" />
            <div>
              <h2 className="text-sm font-bold text-[#202B24]">
                Tham Số Tầng Đất & Hạ Tầng Bảo Mật
              </h2>
              <p className="text-[11px] text-[#718078] mt-0.5">
                Thông số quy đổi nồng độ sang khối lượng đất mặt và trạng thái máy chủ.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-[#718078] mb-1">
                Độ sâu tầng đất (m):
              </label>
              <input
                type="number"
                step="0.05"
                min="0.05"
                max="1.0"
                value={configs.SOIL_DEPTH_M}
                onChange={(e) => handleChange('SOIL_DEPTH_M', e.target.value)}
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                required
              />
            </div>
            <div>
              <label className="block font-semibold text-[#718078] mb-1">
                Dung trọng đất (tấn/m³):
              </label>
              <input
                type="number"
                step="0.05"
                min="0.5"
                max="2.5"
                value={configs.SOIL_BULK_DENSITY}
                onChange={(e) => handleChange('SOIL_BULK_DENSITY', e.target.value)}
                className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg px-3 py-2 font-mono text-[#202B24] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
                required
              />
            </div>
          </div>

          <div className="space-y-2.5 text-xs pt-2 border-t border-[#E5EBE6]">
            <div className="p-2.5 bg-[#FAFCFA] border border-[#E5EBE6] rounded-lg flex items-center justify-between">
              <div>
                <div className="font-semibold text-[#202B24]">MySQL Server Database</div>
                <div className="text-[11px] text-[#718078] font-mono">127.0.0.1:3306 / soil_iot_db</div>
              </div>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-[#EAF4EC] text-[#27864B]">
                Connected
              </span>
            </div>

            <div className="p-2.5 bg-[#FAFCFA] border border-[#E5EBE6] rounded-lg flex items-center justify-between">
              <div>
                <div className="font-semibold text-[#202B24]">Cơ chế bảo mật IoT & Auth</div>
                <div className="text-[11px] text-[#718078] font-mono">SHA-256 API Key • BCrypt + JWT 8h</div>
              </div>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-[#EBF3FA] text-[#4387C5]">
                Secure
              </span>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}
