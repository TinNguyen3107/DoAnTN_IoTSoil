import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  SlidersHorizontal, 
  RotateCcw, 
  Save, 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle,
  RefreshCw,
  Info
} from 'lucide-react';

export default function ThresholdConfig() {
  const [thresholds, setThresholds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [validationErrors, setValidationErrors] = useState({});

  // Step 2 & 3: Tải danh sách ngưỡng hiện tại từ máy chủ
  const fetchThresholds = async () => {
    try {
      setLoading(true);
      setErrorMessage('');
      const res = await axios.get('/api/thresholds');
      if (res.data?.success) {
        setThresholds(res.data.data);
      }
    } catch (err) {
      setErrorMessage(err.response?.data?.message || 'Không thể tải cấu hình ngưỡng từ máy chủ.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchThresholds();
  }, []);

  // Step 4a (Nhánh opt): Khôi phục ngưỡng mặc định chuẩn nông nghiệp Việt Nam
  const handleRestoreDefaults = async () => {
    try {
      const res = await axios.get('/api/thresholds/defaults');
      if (res.data?.success) {
        setThresholds(res.data.data);
        setValidationErrors({});
        setSuccessMessage('Đã tự động điền các giá trị dải ngưỡng chuẩn nông nghiệp Việt Nam. Hãy nhấn "Lưu cấu hình" để áp dụng vào CSDL.');
        setTimeout(() => setSuccessMessage(''), 5000);
      }
    } catch (err) {
      setErrorMessage('Không thể lấy cấu hình chuẩn mặc định.');
    }
  };

  // Step 5 & 6 (Nhánh opt [6a]): Xử lý chỉnh sửa và kiểm tra tính hợp lệ dữ liệu nhập
  const handleValueChange = (parameter, field, value) => {
    const updated = thresholds.map((item) => {
      if (item.parameter === parameter) {
        return { ...item, [field]: value };
      }
      return item;
    });
    setThresholds(updated);

    // Kiểm tra ràng buộc logic Step 6: Min < Max
    const targetItem = updated.find(item => item.parameter === parameter);
    const low = parseFloat(targetItem.low_limit);
    const high = parseFloat(targetItem.high_limit);

    const errors = { ...validationErrors };
    if (!isNaN(low) && !isNaN(high) && low >= high) {
      // Step 6a: Báo lỗi đỏ nếu Mức tối thiểu >= Mức tối đa
      errors[parameter] = `Lỗi logic: Ngưỡng Min (${low}) phải nhỏ hơn Max (${high})`;
    } else if (isNaN(low) || isNaN(high)) {
      errors[parameter] = 'Vui lòng nhập giá trị số hợp lệ';
    } else if (low < 0 || high < 0) {
      errors[parameter] = 'Giá trị ngưỡng không được là số âm';
    } else {
      delete errors[parameter];
    }

    setValidationErrors(errors);
  };

  // Step 7: Gửi dữ liệu cấu hình mới lên máy chủ
  const handleSave = async () => {
    if (Object.keys(validationErrors).length > 0) {
      setErrorMessage('Vui lòng điều chỉnh lại các trường nhập liệu đang báo lỗi đỏ trước khi lưu.');
      return;
    }

    try {
      setSaving(true);
      setErrorMessage('');
      setSuccessMessage('');

      const res = await axios.put('/api/thresholds', {
        thresholds: thresholds.map(t => ({
          parameter: t.parameter,
          low_limit: parseFloat(t.low_limit),
          high_limit: parseFloat(t.high_limit)
        }))
      });

      // Step 8 & 9: Phản hồi thành công có hiệu lực tức thời
      if (res.data?.success) {
        setThresholds(res.data.data);
        setSuccessMessage('Dải ngưỡng cảnh báo mới đã được cập nhật thành công vào CSDL và áp dụng ngay cho các chu trình đo tiếp theo.');
        setTimeout(() => setSuccessMessage(''), 6000);
      }
    } catch (err) {
      setErrorMessage(err.response?.data?.message || 'Có lỗi xảy ra khi cập nhật cấu hình ngưỡng.');
    } finally {
      setSaving(false);
    }
  };

  const hasErrors = Object.keys(validationErrors).length > 0;

  return (
    <div className="space-y-6">
      {/* Header Điều hành */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Cấu Hình Ngưỡng Cảnh Báo Chất Lượng Đất
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Thiết lập dải ngưỡng an toàn (Mức Min – Mức Max) làm căn cứ quét vi phạm tự động khi cảm biến gửi số liệu lên máy chủ.
          </p>
        </div>

        {/* Nút thao tác: Step 4a & Step 7 */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleRestoreDefaults}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#E5EBE6] bg-white hover:bg-[#F2F5F3] text-xs font-semibold text-[#718078] hover:text-[#202B24] transition-colors shadow-xs"
            title="Đưa các ngưỡng về giá trị chuẩn nông nghiệp Việt Nam (pH 5.5 - 6.5, EC 300 - 800...)"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Khôi Phục Chuẩn TCVN</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            disabled={saving || hasErrors || loading}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-white text-xs font-semibold transition-all shadow-xs ${
              hasErrors || saving || loading
                ? 'bg-slate-300 cursor-not-allowed text-slate-500'
                : 'bg-[#27864B] hover:bg-[#1F713E]'
            }`}
            title={hasErrors ? "Khóa nút lưu do có trường nhập sai logic Min >= Max" : "Lưu cấu hình vào CSDL"}
          >
            {saving ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Đang lưu...</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                <span>Lưu Cấu Hình Ngưỡng</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Thông báo Thành công / Lỗi (Step 9 & Step 6a) */}
      {successMessage && (
        <div className="p-3.5 bg-[#EAF4EC] border border-[#CDE5D4] rounded-xl text-xs text-[#27864B] flex items-start gap-2.5 shadow-subtle animate-in fade-in-50">
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="leading-relaxed font-medium">{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 bg-[#FCECEC] border border-[#F8D2D2] rounded-xl text-xs text-[#DC6262] flex items-start gap-2.5 shadow-subtle animate-in fade-in-50">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="leading-relaxed font-medium">{errorMessage}</span>
        </div>
      )}

      {hasErrors && (
        <div className="p-3 bg-[#FFFBEB] border border-[#FEE685] rounded-xl text-xs text-[#8C5810] flex items-center gap-2 shadow-subtle">
          <AlertTriangle className="w-4 h-4 text-[#D97706] shrink-0" />
          <span>Hệ thống phát hiện lỗi logic nhập liệu (Mức tối thiểu Min $\ge$ Max). Nút Lưu cấu hình đã tạm thời bị khóa.</span>
        </div>
      )}

      {/* Bảng cấu hình ngưỡng (Step 4 & Step 5) */}
      <div className="bg-white border border-[#E5EBE6] rounded-card shadow-subtle overflow-hidden">
        {loading ? (
          <div className="p-16 text-center text-xs text-[#718078]">
            <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
            Đang tải dữ liệu ngưỡng từ CSDL MySQL...
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAFCFA] border-b border-[#E5EBE6] text-[#718078] font-semibold">
                <tr>
                  <th className="py-3.5 px-4 w-48">THÔNG SỐ THỔ NHƯỠNG</th>
                  <th className="py-3.5 px-4 w-36">MỨC TỐI THIỂU (MIN)</th>
                  <th className="py-3.5 px-4 w-36">MỨC TỐI ĐA (MAX)</th>
                  <th className="py-3.5 px-4 w-28">ĐƠN VỊ ĐO</th>
                  <th className="py-3.5 px-4">Ý NGHĨA NÔNG HỌC & GIỚI HẠN AN TOÀN</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5EBE6] text-[#202B24]">
                {thresholds.map((item) => {
                  const error = validationErrors[item.parameter];
                  return (
                    <tr 
                      key={item.parameter} 
                      className={`transition-colors ${error ? 'bg-[#FFF9F9]' : 'hover:bg-[#F9FBFA]'}`}
                    >
                      {/* Tên chỉ số */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-[#202B24]">{item.name}</div>
                        <div className="text-[10px] font-mono text-[#718078] uppercase">{item.parameter}</div>
                      </td>

                      {/* Ô nhập Min */}
                      <td className="py-3.5 px-4">
                        <div className="relative">
                          <input
                            type="number"
                            step="0.1"
                            value={item.low_limit}
                            onChange={(e) => handleValueChange(item.parameter, 'low_limit', e.target.value)}
                            className={`w-full rounded-lg px-3 py-1.5 text-xs font-mono font-semibold focus:outline-none transition-colors ${
                              error 
                                ? 'bg-red-50 border-2 border-[#DC6262] text-[#DC6262]' 
                                : 'bg-[#F7F9F7] border border-[#E5EBE6] text-[#202B24] focus:border-[#27864B] focus:bg-white'
                            }`}
                          />
                        </div>
                      </td>

                      {/* Ô nhập Max */}
                      <td className="py-3.5 px-4">
                        <div className="relative">
                          <input
                            type="number"
                            step="0.1"
                            value={item.high_limit}
                            onChange={(e) => handleValueChange(item.parameter, 'high_limit', e.target.value)}
                            className={`w-full rounded-lg px-3 py-1.5 text-xs font-mono font-semibold focus:outline-none transition-colors ${
                              error 
                                ? 'bg-red-50 border-2 border-[#DC6262] text-[#DC6262]' 
                                : 'bg-[#F7F9F7] border border-[#E5EBE6] text-[#202B24] focus:border-[#27864B] focus:bg-white'
                            }`}
                          />
                        </div>
                      </td>

                      {/* Đơn vị đo */}
                      <td className="py-3.5 px-4 font-mono font-medium text-[#718078]">
                        {item.unit}
                      </td>

                      {/* Ý nghĩa nông học & Báo lỗi Step 6a */}
                      <td className="py-3.5 px-4">
                        {error ? (
                          <div className="text-[11px] font-semibold text-[#DC6262] flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                            <span>{error}</span>
                          </div>
                        ) : (
                          <div className="text-[11px] text-[#718078]">
                            {item.description}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Ghi chú quy tắc nông học */}
      <div className="p-4 bg-white border border-[#E5EBE6] rounded-card shadow-subtle flex items-start gap-3">
        <Info className="w-4 h-4 text-[#27864B] shrink-0 mt-0.5" />
        <div className="text-xs text-[#718078] leading-relaxed">
          <strong className="text-[#202B24]">Quy tắc vận hành:</strong> Khi các trạm đo (ESP32 cố định hoặc Máy cầm tay) gửi số liệu lên cổng tiếp nhận, máy chủ sẽ tự động đối chiếu các chỉ số với dải ngưỡng trên. Nếu nồng độ chất trong đất vượt mức trần (Max) hoặc rơi xuống dưới mức sàn (Min), hệ thống sẽ lập tức tạo bản ghi cảnh báo gửi về chuông thông báo cho nông dân.
        </div>
      </div>
    </div>
  );
}
