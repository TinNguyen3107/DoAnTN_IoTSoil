import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Bell, 
  RefreshCw, 
  ChevronRight, 
  AlertCircle,
  AlertTriangle,
  Check,
  CheckCheck,
  LogOut,
  ShieldCheck,
  ExternalLink
} from 'lucide-react';

export default function Topbar({ 
  breadcrumbs = ['Tổng quan'],
  onRefresh,
  isRefreshing = false,
  currentUser,
  onLogout,
  onOpenAlerts
}) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [recentAlerts, setRecentAlerts] = useState([]);
  const [loadingAlerts, setLoadingAlerts] = useState(false);

  const isAdmin = currentUser?.role === 'admin';

  // Lấy số lượng cảnh báo chưa xử lý (UC-12 Step 1 - Huy hiệu chuông)
  const fetchUnreadCount = async () => {
    try {
      const res = await axios.get('/api/alerts/unread-count');
      if (res.data?.success) {
        setUnreadCount(res.data.data.unreadCount || 0);
      }
    } catch (err) {
      // Bỏ qua lỗi nếu chưa đăng nhập
    }
  };

  // Lấy danh sách cảnh báo chưa đọc khi mở Popover (UC-12 Step 2, 3)
  const fetchRecentAlerts = async () => {
    try {
      setLoadingAlerts(true);
      const res = await axios.get('/api/alerts?unreadOnly=true&limit=5');
      if (res.data?.success) {
        setRecentAlerts(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi nạp cảnh báo:', err);
    } finally {
      setLoadingAlerts(false);
    }
  };

  useEffect(() => {
    fetchUnreadCount();
    const interval = setInterval(fetchUnreadCount, 15000); // Tự động quét lại mỗi 15s
    return () => clearInterval(interval);
  }, []);

  const handleTogglePopover = () => {
    if (!showNotifications) {
      fetchRecentAlerts();
    }
    setShowNotifications(!showNotifications);
  };

  // UC-13 Step 1a: Đánh dấu tất cả là đã đọc
  const handleResolveAll = async () => {
    try {
      await axios.patch('/api/alerts/resolve-all');
      setUnreadCount(0);
      setRecentAlerts([]);
    } catch (err) {
      console.error('Lỗi giải quyết toàn bộ cảnh báo:', err);
    }
  };

  // UC-13 Step 1: Đánh dấu 1 cảnh báo đã xử lý
  const handleResolveOne = async (alertId) => {
    try {
      await axios.patch(`/api/alerts/${alertId}/resolve`, {
        actionTaken: 'Nông dân đã xử lý qua thanh thông báo'
      });
      setUnreadCount(prev => Math.max(0, prev - 1));
      setRecentAlerts(prev => prev.filter(a => a.id !== alertId));
    } catch (err) {
      console.error('Lỗi xử lý cảnh báo:', err);
    }
  };

  return (
    <header className="h-16 bg-white border-b border-[#E5EBE6] px-6 flex items-center justify-between sticky top-0 z-30 select-none">
      {/* Left: Breadcrumbs & Page Context */}
      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center text-xs text-[#718078] gap-1.5">
          <span>Hệ thống</span>
          <ChevronRight className="w-3.5 h-3.5 text-[#9CAAA2]" />
          {breadcrumbs.map((crumb, idx) => (
            <React.Fragment key={idx}>
              <span className={idx === breadcrumbs.length - 1 ? 'text-[#202B24] font-medium' : ''}>
                {crumb}
              </span>
              {idx < breadcrumbs.length - 1 && (
                <ChevronRight className="w-3.5 h-3.5 text-[#9CAAA2]" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-3">
        {/* Status Pill */}
        <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#EAF4EC] border border-[#CDE5D4] text-xs text-[#27864B] font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-[#27864B] animate-pulse"></span>
          <span>Hệ thống trực tuyến</span>
        </div>

        {/* Refresh Button */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-lg text-[#718078] hover:text-[#202B24] hover:bg-[#F2F5F3] border border-transparent hover:border-[#E5EBE6] transition-all"
            title="Làm mới dữ liệu từ máy chủ"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#27864B]' : ''}`} />
          </button>
        )}

        {/* UC-12: Chuông thông báo cảnh báo vượt ngưỡng */}
        <div className="relative">
          <button
            onClick={handleTogglePopover}
            className="p-2 rounded-lg text-[#718078] hover:text-[#202B24] hover:bg-[#F2F5F3] border border-transparent hover:border-[#E5EBE6] transition-all relative"
            title="Thông báo cảnh báo vượt ngưỡng"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#DC6262] text-white text-[10px] font-mono font-bold flex items-center justify-center animate-pulse border-2 border-white shadow-xs">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </button>

          {/* UC-12 & UC-13: Notification Popover */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-96 bg-white rounded-2xl border border-[#E5EBE6] shadow-modal py-3 z-50 animate-in fade-in-50">
              <div className="px-4 pb-2.5 border-b border-[#E5EBE6] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#202B24] uppercase tracking-wide">
                    Cảnh Báo Vượt Ngưỡng
                  </span>
                  {unreadCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded font-mono text-[10px] font-bold bg-[#FCECEC] text-[#DC6262]">
                      {unreadCount}
                    </span>
                  )}
                </div>

                {unreadCount > 0 && (
                  <button
                    onClick={handleResolveAll}
                    className="text-[11px] font-semibold text-[#27864B] hover:text-[#1F713E] flex items-center gap-1"
                    title="Đánh dấu tất cả là đã đọc (UC-13 Step 1a)"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    <span>Đọc tất cả</span>
                  </button>
                )}
              </div>

              {/* Danh sách cảnh báo chưa đọc */}
              <div className="max-h-80 overflow-y-auto px-3 py-2 space-y-2">
                {loadingAlerts ? (
                  <div className="py-8 text-center text-xs text-[#718078]">
                    <RefreshCw className="w-4 h-4 animate-spin mx-auto mb-1 text-[#27864B]" />
                    Đang quét danh sách cảnh báo...
                  </div>
                ) : recentAlerts.length === 0 ? (
                  // UC-12 Step 3a: Không còn cảnh báo chưa đọc
                  <div className="py-6 text-center text-xs text-[#718078] space-y-1">
                    <Check className="w-6 h-6 text-[#26965A] mx-auto mb-1" />
                    <div className="font-semibold text-[#202B24]">Không có cảnh báo mới</div>
                    <div className="text-[11px]">Tất cả chỉ số thổ nhưỡng hiện đang an toàn.</div>
                  </div>
                ) : (
                  recentAlerts.map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-3 rounded-xl border text-xs space-y-1.5 transition-all ${
                        alert.level === 'danger'
                          ? 'bg-[#FFF8F8] border-[#F8D2D2]'
                          : 'bg-[#FFFCF5] border-[#FEE685]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.2 rounded ${
                          alert.level === 'danger'
                            ? 'bg-[#FCECEC] text-[#DC6262]'
                            : 'bg-[#FDF6E9] text-[#D97706]'
                        }`}>
                          {alert.level === 'danger' ? 'NGUY HIỂM' : 'CẢNH BÁO'}
                        </span>
                        <span className="text-[10px] text-[#718078] font-mono">
                          {new Date(alert.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="font-bold text-[#202B24] flex items-center justify-between">
                        <span>{alert.parameterName}: {alert.value} {alert.unit}</span>
                        <span className="text-[10px] text-[#718078] font-normal font-mono">(Ngưỡng: {alert.limitValue})</span>
                      </div>

                      <p className="text-[11px] text-[#718078] leading-tight">
                        {alert.diagnosticMessage}
                      </p>

                      <div className="pt-1 flex items-center justify-between border-t border-black/5">
                        <span className="text-[10px] text-[#718078] font-medium truncate max-w-[180px]">
                          {alert.deviceName}
                        </span>
                        <button
                          onClick={() => handleResolveOne(alert.id)}
                          className="text-[10px] font-semibold text-[#27864B] hover:text-[#1F713E] flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-[#CDE5D4]"
                        >
                          <Check className="w-3 h-3" />
                          <span>Đã xử lý</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Footer Xem toàn bộ */}
              <div className="px-4 pt-2 border-t border-[#E5EBE6] text-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    onOpenAlerts?.();
                  }}
                  className="text-xs font-semibold text-[#27864B] hover:text-[#1F713E] inline-flex items-center gap-1"
                >
                  <span>Xem tất cả cảnh báo</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Account Profile Pill */}
        <div className="flex items-center gap-3 pl-3 border-l border-[#E5EBE6]">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg text-white flex items-center justify-center font-bold text-xs shadow-xs ${
              isAdmin ? 'bg-[#27864B]' : 'bg-[#D97706]'
            }`}>
              {currentUser?.fullName?.charAt(0) || (isAdmin ? 'A' : 'N')}
            </div>
            <div className="hidden lg:block text-left leading-tight">
              <div className="text-xs font-semibold text-[#202B24]">{currentUser?.fullName}</div>
              <div className="text-[11px] text-[#718078] flex items-center gap-1">
                <span>{currentUser?.email}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-medium ${
                  isAdmin ? 'bg-[#EAF4EC] text-[#27864B]' : 'bg-[#FDF6E9] text-[#D97706]'
                }`}>
                  {isAdmin ? 'Quản trị viên' : 'Nông dân'}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="p-1.5 rounded-lg text-[#9CAAA2] hover:text-[#DC6262] hover:bg-[#FCECEC] transition-colors"
            title="Đăng xuất"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
