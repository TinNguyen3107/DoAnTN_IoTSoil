import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Users, 
  ShieldCheck, 
  UserCheck, 
  Lock, 
  Unlock, 
  Search, 
  RefreshCw, 
  Shield, 
  AlertCircle, 
  CheckCircle2, 
  X,
  Radio,
  UserPlus
} from 'lucide-react';

export default function UserManagement({ currentUser }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  // Modal Đổi Quyền (UC-18)
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [selectedUserForRole, setSelectedUserForRole] = useState(null);
  const [newRole, setNewRole] = useState('farmer');
  const [updatingRole, setUpdatingRole] = useState(false);
  const [roleError, setRoleError] = useState('');

  // Tải danh sách người dùng (UC-17 Step 2 & 4)
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await axios.get('/api/users');
      if (res.data?.success) {
        setUsers(res.data.data);
      }
    } catch (err) {
      console.error('Lỗi tải danh sách người dùng:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Khóa / Mở khóa tài khoản (UC-17 Step 8 & 9)
  const handleToggleStatus = async (user) => {
    // UC-17 Alt 9a: Kiểm tra không thể tự khóa chính mình
    if (user.id === currentUser?.id) {
      alert('⚠️ Quy tắc an toàn: Quản trị viên không thể tự khóa tài khoản của chính mình.');
      return;
    }

    const nextStatus = !user.isActive;
    const actionText = nextStatus ? 'kích hoạt lại' : 'tạm khóa';

    if (!window.confirm(`Xác nhận ${actionText} tài khoản "${user.fullName}" (${user.email})?`)) {
      return;
    }

    try {
      const res = await axios.patch(`/api/users/${user.id}/status`, {
        isActive: nextStatus
      });
      if (res.data?.success) {
        fetchUsers();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Có lỗi xảy ra khi cập nhật trạng thái tài khoản.');
    }
  };

  // Mở modal đổi quyền (UC-18 Step 4)
  const openRoleModal = (user) => {
    setSelectedUserForRole(user);
    setNewRole(user.role);
    setRoleError('');
    setShowRoleModal(true);
  };

  // Lưu phân quyền vai trò (UC-18 Step 5, 6, 7)
  const handleSaveRole = async (e) => {
    e.preventDefault();
    if (!selectedUserForRole) return;

    try {
      setUpdatingRole(true);
      setRoleError('');
      const res = await axios.patch(`/api/users/${selectedUserForRole.id}/role`, {
        role: newRole
      });
      if (res.data?.success) {
        setShowRoleModal(false);
        fetchUsers();
      }
    } catch (err) {
      setRoleError(err.response?.data?.message || 'Có lỗi xảy ra khi phân quyền vai trò.');
    } finally {
      setUpdatingRole(false);
    }
  };

  // Lọc người dùng theo tìm kiếm & vai trò
  const filteredUsers = users.filter((u) => {
    const matchesSearch = 
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6">
      {/* Tiêu đề trang & Thao tác */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <h1 className="text-xl font-bold text-[#202B24] tracking-tight">
            Quản Trị Người Dùng & Phân Quyền
          </h1>
          <p className="text-xs text-[#718078] mt-1">
            Theo dõi toàn bộ danh sách tài khoản, số trạm đo sở hữu, kiểm soát trạng thái hoạt động và phân định vai trò Quản trị viên / Nông dân.
          </p>
        </div>

        <button
          onClick={fetchUsers}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#E5EBE6] bg-white hover:bg-[#F2F5F3] text-xs font-semibold text-[#202B24] transition-colors shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#27864B]' : ''}`} />
          <span>Làm Mới Danh Sách</span>
        </button>
      </div>

      {/* Thanh tìm kiếm & Bộ lọc vai trò */}
      <div className="bg-white border border-[#E5EBE6] rounded-card p-3 shadow-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9CAAA2]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm theo họ tên hoặc email..."
            className="w-full bg-[#F7F9F7] border border-[#E5EBE6] rounded-lg pl-9 pr-3.5 py-1.5 text-xs text-[#202B24] placeholder-[#9CAAA2] focus:outline-none focus:border-[#27864B] focus:bg-white transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <div className="inline-flex p-0.5 rounded-lg bg-[#F7F9F7] border border-[#E5EBE6] text-xs">
            <button
              onClick={() => setRoleFilter('all')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                roleFilter === 'all'
                  ? 'bg-white text-[#202B24] shadow-xs font-semibold'
                  : 'text-[#718078] hover:text-[#202B24]'
              }`}
            >
              Tất cả ({users.length})
            </button>
            <button
              onClick={() => setRoleFilter('admin')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                roleFilter === 'admin'
                  ? 'bg-white text-[#27864B] shadow-xs font-semibold'
                  : 'text-[#718078] hover:text-[#202B24]'
              }`}
            >
              Quản trị viên ({users.filter(u => u.role === 'admin').length})
            </button>
            <button
              onClick={() => setRoleFilter('farmer')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                roleFilter === 'farmer'
                  ? 'bg-white text-[#D97706] shadow-xs font-semibold'
                  : 'text-[#718078] hover:text-[#202B24]'
              }`}
            >
              Nông dân ({users.filter(u => u.role === 'farmer').length})
            </button>
          </div>
        </div>
      </div>

      {/* Bảng Danh Sách Tài Khoản */}
      <div className="bg-white border border-[#E5EBE6] rounded-card shadow-subtle overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-xs text-[#718078]">
            <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#27864B]" />
            Đang tải dữ liệu tài khoản người dùng...
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="py-16 text-center text-xs text-[#718078]">
            Không tìm thấy tài khoản người dùng nào phù hợp.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAFCFA] border-b border-[#E5EBE6] text-[#718078] font-semibold">
                <tr>
                  <th className="py-3 px-4">MÃ ID</th>
                  <th className="py-3 px-4">HỌ VÀ TÊN</th>
                  <th className="py-3 px-4">EMAIL ĐĂNG NHẬP</th>
                  <th className="py-3 px-4">VAI TRÒ HỆ THỐNG</th>
                  <th className="py-3 px-4">SỐ TRẠM SỞ HỮU</th>
                  <th className="py-3 px-4">TRẠNG THÁI</th>
                  <th className="py-3 px-4 text-right">THAO TÁC QUẢN TRỊ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5EBE6] text-[#202B24]">
                {filteredUsers.map((u) => {
                  const isCurrent = u.id === currentUser?.id;
                  const isAdmin = u.role === 'admin';

                  return (
                    <tr key={u.id} className="hover:bg-[#F9FBFA] transition-colors">
                      <td className="py-3.5 px-4 font-mono font-medium text-[#718078]">
                        #{String(u.id).padStart(3, '0')}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-[#202B24] flex items-center gap-1.5">
                          <span>{u.fullName}</span>
                          {isCurrent && (
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#EAF4EC] text-[#27864B] font-bold">
                              Bạn
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[#718078]">
                        {u.email}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                          isAdmin 
                            ? 'bg-[#EAF4EC] text-[#27864B] border-[#CDE5D4]' 
                            : 'bg-[#FDF6E9] text-[#D97706] border-[#FDE68A]'
                        }`}>
                          {isAdmin ? <ShieldCheck className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                          <span>{isAdmin ? 'Quản trị viên' : 'Chủ hộ nông dân'}</span>
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono">
                        <span className="px-2 py-0.5 rounded bg-[#F2F5F3] text-[#718078] text-[11px] font-semibold">
                          {u.devicesCount} trạm đo
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        {u.isActive ? (
                          <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#26965A]">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#26965A]"></span>
                            <span>Đang hoạt động</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#DC6262]">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#DC6262]"></span>
                            <span>Tạm khóa</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right space-x-1.5">
                        {/* Nút Đổi Quyền (UC-18) */}
                        <button
                          onClick={() => openRoleModal(u)}
                          className="px-2.5 py-1 rounded-lg border border-[#E5EBE6] hover:bg-[#F2F5F3] text-[#202B24] text-[11px] font-medium transition-colors"
                          title="Thay đổi vai trò quản trị / nông dân"
                        >
                          Đổi Quyền
                        </button>

                        {/* Nút Khóa / Mở Khóa (UC-17) */}
                        {isCurrent ? (
                          <button
                            disabled
                            className="px-2.5 py-1 rounded-lg border border-[#E5EBE6] bg-[#F2F5F3] text-[#9CAAA2] text-[11px] font-medium cursor-not-allowed opacity-50"
                            title="Không thể tự khóa tài khoản của chính mình (UC-17 Alt 9a)"
                          >
                            Khóa
                          </button>
                        ) : (
                          <button
                            onClick={() => handleToggleStatus(u)}
                            className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-colors ${
                              u.isActive
                                ? 'border-[#E5EBE6] text-[#DC6262] hover:bg-[#FCECEC] hover:border-[#F8D2D2]'
                                : 'border-[#CDE5D4] text-[#27864B] bg-[#EAF4EC] hover:bg-[#DDF0E1]'
                            }`}
                          >
                            {u.isActive ? 'Khóa' : 'Kích hoạt'}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL PHÂN QUYỀN VAI TRÒ (UC-18 Step 4, 5, 6) */}
      {showRoleModal && selectedUserForRole && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in-50">
          <div className="bg-white rounded-2xl border border-[#E5EBE6] shadow-modal max-w-md w-full overflow-hidden">
            <div className="px-6 py-4 border-b border-[#E5EBE6] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#EAF4EC] text-[#27864B] flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#202B24]">Phân Quyền Vai Trò Người Dùng</h3>
                  <p className="text-[11px] text-[#718078]">Cập nhật phạm vi quyền truy cập các tính năng hệ thống</p>
                </div>
              </div>

              <button
                onClick={() => setShowRoleModal(false)}
                className="p-1.5 rounded-lg text-[#9CAAA2] hover:text-[#202B24] hover:bg-[#F2F5F3]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveRole} className="p-6 space-y-4">
              {roleError && (
                <div className="p-3 bg-[#FCECEC] border border-[#F8D2D2] text-[#DC6262] rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{roleError}</span>
                </div>
              )}

              {/* Thông tin tài khoản được chọn */}
              <div className="p-3 bg-[#F7F9F7] border border-[#E5EBE6] rounded-xl text-xs space-y-1">
                <div className="font-semibold text-[#202B24]">{selectedUserForRole.fullName}</div>
                <div className="text-[#718078] font-mono">{selectedUserForRole.email}</div>
                <div className="text-[11px] text-[#718078] pt-1">
                  Vai trò hiện tại:{' '}
                  <span className="font-bold text-[#202B24]">
                    {selectedUserForRole.role === 'admin' ? 'Quản trị viên' : 'Chủ hộ nông dân'}
                  </span>
                </div>
              </div>

              {/* Lựa chọn vai trò mới */}
              <div>
                <label className="block text-xs font-semibold text-[#202B24] mb-1.5">
                  Chọn vai trò mới:
                </label>
                <div className="space-y-2">
                  <label className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                    newRole === 'farmer'
                      ? 'bg-[#FDF6E9]/40 border-[#FDE68A] text-[#202B24]'
                      : 'border-[#E5EBE6] hover:bg-[#F9FBFA]'
                  }`}>
                    <input
                      type="radio"
                      name="role"
                      value="farmer"
                      checked={newRole === 'farmer'}
                      onChange={() => setNewRole('farmer')}
                      className="mt-0.5 text-[#27864B] focus:ring-[#27864B]"
                    />
                    <div>
                      <div className="text-xs font-bold text-[#202B24]">Chủ Hộ Nông Dân (Farmer)</div>
                      <div className="text-[11px] text-[#718078] mt-0.5">
                        Chỉ truy cập các trạm đo thuộc quyền sở hữu cá nhân, theo dõi thời gian thực, xem biểu đồ, ghi sổ nhật ký và nhận tư vấn NPK.
                      </div>
                    </div>
                  </label>

                  <label className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                    newRole === 'admin'
                      ? 'bg-[#EAF4EC]/50 border-[#CDE5D4] text-[#202B24]'
                      : 'border-[#E5EBE6] hover:bg-[#F9FBFA]'
                  }`}>
                    <input
                      type="radio"
                      name="role"
                      value="admin"
                      checked={newRole === 'admin'}
                      onChange={() => setNewRole('admin')}
                      className="mt-0.5 text-[#27864B] focus:ring-[#27864B]"
                    />
                    <div>
                      <div className="text-xs font-bold text-[#202B24]">Quản Trị Viên (Admin)</div>
                      <div className="text-[11px] text-[#718078] mt-0.5">
                        Toàn quyền xem dashboard tổng quan, quản lý tất cả thiết bị trạm đo, cấu hình ngưỡng cảnh báo, quản trị người dùng và cài đặt tham số.
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Nút hành động */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowRoleModal(false)}
                  className="px-4 py-2 rounded-lg border border-[#E5EBE6] text-xs font-semibold text-[#718078] hover:bg-[#F2F5F3]"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={updatingRole}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#27864B] hover:bg-[#1F713E] text-white text-xs font-semibold transition-colors shadow-xs"
                >
                  {updatingRole ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Đang lưu...</span>
                    </>
                  ) : (
                    <span>Lưu Phân Quyền</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
